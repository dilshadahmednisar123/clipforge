# ClipForge AI

**Free, local-first AI video repurposing platform**

Inspired by the workflow of Opus Clip, built with original branding and a fully local processing pipeline. No Gemini, no OpenAI, no mandatory cloud AI subscriptions.

## Modes

| Mode | Requirements | Capabilities |
|------|--------------|--------------|
| **Browser Lite** | Browser + FFmpeg on server (or local Next.js) | Import, validate, basic trim/crop/export |
| **Full Local AI** | Python worker + faster-whisper + optional vision models | Transcription, highlight scoring, smart reframing, captions |
| **Desktop** | Electron + local FFmpeg (`npm run desktop`) | Same as full local, in a native window — see [docs/DESKTOP.md](docs/DESKTOP.md) |

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Check system readiness (FFmpeg, storage, etc.)
npm run setup

# 3a. Web app
npm run dev
# → http://localhost:3000

# 3b. Desktop app (Electron window)
npm run desktop
```

### Optional: Full Local AI worker

```bash
# Install Python deps (once)
pip install fastapi uvicorn faster-whisper silero-vad opencv-python-headless

# Start worker (separate terminal)
npm run worker
# → http://localhost:8765
```

Then open **Model Manager** in the UI to download a quantized Whisper model (with size confirmation).

## Architecture

- **Frontend**: Next.js 15 (App Router), React 18, TypeScript, Tailwind CSS
- **Media**: FFmpeg / FFprobe (subprocess, argument-array safe)
- **Jobs**: File-backed job state machine under `data/` (QUEUED → TRANSCRIBING → ANALYZING → SELECTING_CLIPS → COMPLETED / FAILED)
- **Scoring**: Deterministic local heuristics (hook, narrative, density, silence penalties) — no remote LLM
- **Worker**: FastAPI process for offline transcription (faster-whisper)
- **Storage**: Local filesystem under `./storage/` + JSON project store under `./data/`

No video or transcript data leaves the machine.

## Phase Status

- [x] **Phase 1** — Foundation, dashboard, media import + FFprobe validation, project structure, setup check
- [x] **Phase 2** — Offline transcription (worker), transcript viewer/search, clip scoring engine, candidate selection, project persistence
- [x] **Phase 3** — Caption styles (SRT/VTT/ASS), vertical/square reframing, clip editor, FFmpeg export with verification + download
- [x] **Phase 4** — Bounded job queue, batch export, cancel/retry, interrupted-job recovery, storage usage, model file listing
- [x] **Phase 5** — Security path helpers, expanded smoke tests, INSTALL + SECURITY docs, `.env.example`
- [x] **Phase 6** — Transcript edit/export (SRT/VTT), source stream + editor preview, loudnorm audio, SSE job events, mobile nav, FFmpeg integration test

## Documentation

- [Installation guide](docs/INSTALL.md) — OS setup, worker, low-RAM tips
- [Desktop app](docs/DESKTOP.md) — Electron shell
- [Free deploy](docs/FREE-DEPLOY.md) — local / Docker / Oracle free VM
- [Security notes](docs/SECURITY.md) — path safety, subprocess policy, threat model

## Project Layout

```
clipforge-ai/
├── src/
│   ├── app/                 # App Router pages & API routes
│   ├── components/
│   ├── lib/
│   │   ├── media/ scoring/ captions/ reframe/ export/
│   │   ├── db/ jobs/ queue/ system/ security/
│   └── types/
├── scripts/                 # setup-check + smoke tests
├── docs/INSTALL.md          # OS install guide
├── docs/SECURITY.md
├── worker/main.py
├── .env.example
├── storage/{uploads,exports,temp,models}/
└── data/                    # projects, jobs, transcripts, clips
```

## Security Notes

See [docs/SECURITY.md](docs/SECURITY.md). Summary:

- Subprocess calls use argument arrays only (no shell interpolation).
- Upload names sanitized; size and type limited; paths under `storage/`.
- Downloads basename-only; resolved under `storage/exports`.
- No external telemetry; no mandatory cloud AI keys.

## License

MIT — use freely. You are responsible for the content you process and any model licenses.
