"""
ClipForge AI — Local processing worker (FastAPI)

Start:
  pip install fastapi uvicorn python-multipart
  # optional transcription:
  pip install faster-whisper

  python3 worker/main.py
"""

from __future__ import annotations

import os
import shutil
import platform
import tempfile
import traceback
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="ClipForge Worker", version="0.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

WHISPER_AVAILABLE = False
WHISPER_MODEL = None
WHISPER_MODEL_SIZE = os.environ.get("CLIPFORGE_WHISPER_SIZE", "tiny")
WHISPER_ERROR: Optional[str] = None

try:
    from faster_whisper import WhisperModel  # type: ignore

    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_ERROR = "faster-whisper not installed. Run: pip install faster-whisper"
except Exception as e:
    WHISPER_ERROR = str(e)


def get_whisper_model():
    global WHISPER_MODEL
    if not WHISPER_AVAILABLE:
        return None
    if WHISPER_MODEL is None:
        WHISPER_MODEL = WhisperModel(
            WHISPER_MODEL_SIZE,
            device="cpu",
            compute_type="int8",
        )
    return WHISPER_MODEL


class HealthResponse(BaseModel):
    status: str
    ffmpeg: bool
    ffprobe: bool
    platform: str
    whisper: bool
    whisper_size: Optional[str] = None
    whisper_error: Optional[str] = None
    version: str


class TranscriptWord(BaseModel):
    word: str
    start: float
    end: float
    confidence: Optional[float] = None


class TranscriptSegment(BaseModel):
    id: str
    start: float
    end: float
    text: str
    speaker: Optional[str] = None
    words: Optional[list[TranscriptWord]] = None


class TranscribeResponse(BaseModel):
    ok: bool
    segments: list[TranscriptSegment] = []
    language: Optional[str] = None
    duration: Optional[float] = None
    error: Optional[str] = None


@app.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse(
        status="ok",
        ffmpeg=shutil.which("ffmpeg") is not None,
        ffprobe=shutil.which("ffprobe") is not None,
        platform=platform.system(),
        whisper=WHISPER_AVAILABLE,
        whisper_size=WHISPER_MODEL_SIZE if WHISPER_AVAILABLE else None,
        whisper_error=WHISPER_ERROR,
        version="0.2.0",
    )


@app.get("/")
def root():
    return {"service": "ClipForge Worker", "docs": "/docs", "health": "/health"}


@app.post("/transcribe", response_model=TranscribeResponse)
async def transcribe(
    path: Optional[str] = Form(None),
    language: Optional[str] = Form(None),
    word_timestamps: bool = Form(True),
    file: Optional[UploadFile] = File(None),
):
    if not WHISPER_AVAILABLE:
        return TranscribeResponse(
            ok=False,
            error=WHISPER_ERROR
            or "faster-whisper is not available. Install it and restart the worker.",
        )

    temp_path: Optional[str] = None
    media_path: Optional[str] = None

    try:
        if path:
            media_path = path
            if not os.path.isfile(media_path):
                raise HTTPException(status_code=400, detail=f"File not found: {path}")
        elif file is not None:
            suffix = Path(file.filename or "audio.wav").suffix or ".wav"
            fd, temp_path = tempfile.mkstemp(suffix=suffix)
            os.close(fd)
            content = await file.read()
            with open(temp_path, "wb") as f:
                f.write(content)
            media_path = temp_path
        else:
            raise HTTPException(
                status_code=400, detail="Provide 'path' form field or upload 'file'"
            )

        model = get_whisper_model()
        if model is None:
            return TranscribeResponse(ok=False, error="Failed to load Whisper model")

        segments_out: list[TranscriptSegment] = []
        detected_lang = language
        info_duration = None

        segments_iter, info = model.transcribe(
            media_path,
            language=language if language and language != "auto" else None,
            word_timestamps=word_timestamps,
            vad_filter=True,
            beam_size=3,
        )
        detected_lang = info.language
        info_duration = getattr(info, "duration", None)

        for i, seg in enumerate(segments_iter):
            words = None
            if word_timestamps and getattr(seg, "words", None):
                words = [
                    TranscriptWord(
                        word=w.word.strip(),
                        start=round(w.start, 3),
                        end=round(w.end, 3),
                        confidence=getattr(w, "probability", None),
                    )
                    for w in seg.words
                    if w.word and w.word.strip()
                ]
            segments_out.append(
                TranscriptSegment(
                    id=f"seg-{i}",
                    start=round(seg.start, 3),
                    end=round(seg.end, 3),
                    text=seg.text.strip(),
                    words=words,
                )
            )

        return TranscribeResponse(
            ok=True,
            segments=segments_out,
            language=detected_lang,
            duration=info_duration,
        )
    except HTTPException:
        raise
    except Exception as e:
        traceback.print_exc()
        return TranscribeResponse(ok=False, error=str(e))
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except OSError:
                pass


@app.post("/extract-audio")
async def extract_audio(path: str = Form(...)):
    if not shutil.which("ffmpeg"):
        raise HTTPException(status_code=500, detail="ffmpeg not found")
    if not os.path.isfile(path):
        raise HTTPException(status_code=400, detail="File not found")

    out = path + ".clipforge.wav"
    import subprocess

    try:
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-i",
                path,
                "-vn",
                "-acodec",
                "pcm_s16le",
                "-ar",
                "16000",
                "-ac",
                "1",
                out,
            ],
            check=True,
            capture_output=True,
            timeout=300,
        )
        return {"ok": True, "path": out}
    except subprocess.CalledProcessError as e:
        raise HTTPException(
            status_code=500,
            detail=e.stderr.decode("utf-8", errors="replace")[:500],
        )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8765, log_level="info")
