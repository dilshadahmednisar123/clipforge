# Deploy ClipForge UI to Vercel

## What works on Vercel

| Feature | On Vercel |
|---------|-----------|
| Dashboard, navigation, settings UI | Yes |
| Project list (ephemeral `/tmp` data) | Partial |
| Import / FFprobe / export / Whisper | **No** (no system FFmpeg) |

Use Vercel to **preview the UI**. For a working video pipeline, use local or Docker (`docs/FREE-DEPLOY.md`).

---

## Deploy with the Vercel website (easiest)

1. Push this repo to **GitHub** (or GitLab / Bitbucket).
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Settings:
   - **Framework Preset:** Next.js  
   - **Root Directory:** `clipforge-ai` (if the repo root is the parent folder)  
   - **Build Command:** `npm run build`  
   - **Install Command:** `npm install`  
4. Click **Deploy**.
5. Open the `*.vercel.app` URL.

No environment variables are required.

---

## Deploy with the CLI

```bash
cd clipforge-ai
npm install
npm install -g vercel   # once

vercel login
vercel                # preview deployment
vercel --prod         # production
```

Follow the prompts (link to a Vercel project / scope).

---

## Expected behavior after deploy

- UI loads at `https://your-project.vercel.app`
- **Create & Analyze** / validate show a clear error that FFmpeg is unavailable
- System status API: `GET /api/system/status` → `"platform": "vercel"`, `fullPipeline: false`

That is intentional — the app degrades instead of crashing.

---

## Optional env vars

None required. If you later point at a remote worker (custom setup):

```
CLIPFORGE_WORKER_URL=https://your-worker.example.com
```

Worker still cannot run FFmpeg *on* Vercel; only on a separate host.

---

## Full pipeline (not Vercel)

```bash
# Local
npm run dev && npm run worker

# Or free public VM
docker compose up -d --build
```

See `docs/FREE-DEPLOY.md`.
