# ClipForge AI — Security Notes

## Threat model (local app)

ClipForge is designed to run on a trusted workstation. It processes **local media** and must not execute untrusted shell strings or serve files outside designated directories.

## Controls implemented

1. **Subprocess safety**  
   FFmpeg / FFprobe are invoked with `execFile` and argument arrays only — never shell string concatenation of user input.

2. **Path traversal**  
   Download endpoints accept basename-only filenames (`[a-zA-Z0-9._-]+`). Resolved paths must stay under `storage/exports` via `resolveUnderRoot`.

3. **Upload hygiene**  
   Filenames are sanitized; size limited (500 MB); video extension / MIME checks applied. Files land under `storage/uploads/` with a random prefix.

4. **No remote AI**  
   Core pipelines do not call Gemini, OpenAI, or other paid APIs. Transcription stays on the local worker when configured.

5. **No mandatory accounts / telemetry**  
   Projects persist in local JSON files. No analytics SDK is included.

6. **Job cancellation**  
   Long-running queue jobs can be cancelled; interrupted jobs are marked failed on recovery rather than silently “succeeding.”

## What this is not

- Not a multi-tenant SaaS hardening pass  
- Not a substitute for OS-level file permissions  
- Not immune to a malicious local user with write access to the project directory  

## Recommendations

- Run `npm run dev` / worker bound to `127.0.0.1` only on shared networks  
- Keep source and export directories on encrypted disks if media is sensitive  
- Review `storage/` before sharing the project folder  
- Do not place secrets in the repo; `.env*.local` is gitignored  

## Reporting issues

Treat path escape or command injection as high priority. Prefer reproducible steps with a sample filename/payload.
