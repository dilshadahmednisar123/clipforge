# ClipForge AI — Desktop app

ClipForge is **local-first**. A desktop shell is the natural product form: system FFmpeg, local disk, optional Whisper worker — no Vercel needed.

## Architecture

```
┌─────────────────────────────────────┐
│  Electron window                     │
│  (loads http://127.0.0.1:3000)       │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│  Next.js (same codebase as web)      │
│  + FFmpeg/FFprobe on PATH            │
│  + storage/ and data/ on disk        │
└──────────────┬──────────────────────┘
               │ optional
┌──────────────▼──────────────────────┐
│  Python worker (faster-whisper)      │
│  npm run worker                      │
└─────────────────────────────────────┘
```

## Prerequisites

1. **Node.js 20+**
2. **FFmpeg + FFprobe** on your PATH  
   - macOS: `brew install ffmpeg`  
   - Windows: `winget install ffmpeg`  
   - Linux: `sudo apt install ffmpeg`
3. (Optional) **Python 3.10+** + `faster-whisper` for real transcription

## Run as desktop app (development)

```bash
cd clipforge-ai
npm install
npm run setup

# Terminal 1 — optional STT worker
npm run worker

# Terminal 2 — desktop window (starts Next + Electron)
npm run desktop
```

Electron starts `next dev`, waits until the server responds, then opens the window.

You can still use the browser at http://localhost:3000 while the desktop app is running.

## Package installers (optional)

```bash
npm run desktop:dist
```

Outputs under `dist-desktop/` (DMG / NSIS / AppImage depending on OS).

**Note:** Packaged builds expect FFmpeg installed on the **user’s system** (not fully bundled). Bundling FFmpeg binaries per OS is possible later as an enhancement.

## Why not only a website?

| Host | Full pipeline |
|------|----------------|
| Desktop / local | Yes |
| Docker / VPS | Yes |
| Vercel alone | No (no system FFmpeg) |

## Alternatives

| Stack | Pros | Cons |
|-------|------|------|
| **Electron** (this repo) | Matches current Node/Next stack | Larger app size |
| **Tauri** | Smaller binary | Extra Rust toolchain; API server still needed |
| **Browser only** | Zero install | Same limits as “web without backend” |

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Window blank / timeout | Run `npm install`, then `npm run setup`; check port 3000 free |
| Validate / export fails | Install FFmpeg; reopen the app |
| Transcription placeholders | Start `npm run worker` with faster-whisper installed |
| Electron not found | `npm install` (electron is a devDependency) |

## Security

- The window loads **only** `http://127.0.0.1` (local server).
- `nodeIntegration` is off; preload is minimal.
- External links open in the system browser.
