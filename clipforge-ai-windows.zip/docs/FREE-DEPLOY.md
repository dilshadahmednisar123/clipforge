# ClipForge AI — Free deployment (actually works)

ClipForge needs **FFmpeg**, **disk**, and optionally a **Python worker**.  
Free serverless (Vercel, Netlify, Cloudflare Workers) cannot run that stack reliably.

## Ranked free options

| Rank | Option | Cost | Works fully? | Notes |
|------|--------|------|--------------|--------|
| 1 | **Your own PC** (`npm run dev`) | $0 | Yes | Best match for local-first design |
| 2 | **Oracle Cloud Always Free VM** | $0 forever* | Yes | Best free public URL |
| 3 | **Docker on any free/cheap VPS** | $0–5/mo | Yes | Same compose file |
| 4 | Vercel / Netlify only | $0 | **No** | UI only; no real FFmpeg pipeline |

\*Subject to Oracle’s always-free terms and account approval.

---

## 1. Local (zero cost, full features)

```bash
cd clipforge-ai
npm install
npm run setup
npm run test
npm run dev
# optional STT:
pip install fastapi uvicorn python-multipart faster-whisper
npm run worker
```

Open http://localhost:3000 — this is the intended production mode for a single user.

---

## 2. Docker Compose (laptop or free VM)

Requires [Docker](https://docs.docker.com/get-docker/).

```bash
cd clipforge-ai
docker compose up -d --build
```

- App: http://localhost:3000  
- Worker: internal only (`http://worker:8765`)  
- Data persists in Docker volumes `clipforge_data` and `clipforge_storage`

Stop:

```bash
docker compose down
```

First Whisper run downloads the **tiny** model (network required once).

---

## 3. Oracle Cloud Always Free (public URL, $0)

### Why Oracle

Always Free **Ampere A1** shape: up to 4 OCPUs + 24 GB RAM (shared across free instances) — enough for FFmpeg + Whisper tiny.

### Steps (summary)

1. Create an Oracle Cloud Free Tier account: https://www.oracle.com/cloud/free/
2. Create a **VM.Standard.A1.Flex** instance (Ubuntu 22.04), assign a public IP.
3. Security list / NSG: allow **ingress TCP 22** and **TCP 3000** (or 80/443 if you add a reverse proxy).
4. SSH in and install Docker:

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-v2 git
sudo usermod -aG docker $USER
# log out and back in
```

5. Deploy:

```bash
git clone <your-repo-url> clipforge-ai
cd clipforge-ai
docker compose up -d --build
```

6. Open `http://YOUR_PUBLIC_IP:3000`

### HTTPS (optional, free)

Use Caddy with a domain pointing at the VM, or Cloudflare Tunnel (free) so you don’t open ports.

---

## 4. What “working perfectly” means on free tier

| Feature | Local / Oracle Docker |
|---------|------------------------|
| Import + FFprobe validate | Yes |
| Heuristic clip scoring | Yes |
| Whisper transcription | Yes (tiny model; first run downloads) |
| Caption burn-in + vertical export | Yes |
| Batch queue / cancel / retry | Yes |
| Data after reboot | Yes (Docker volumes or local `data/` + `storage/`) |

Limits of free hosting:

- Slow CPU → long videos take time (set `CLIPFORGE_MAX_JOBS=1`)
- Don’t expose the worker port publicly
- Oracle may reclaim idle free resources; snapshot volumes if needed

---

## 5. Do not use for “perfect” full pipeline

- **Vercel / Netlify / Cloudflare Pages** alone  
- **Render / Railway free** sleep tiers for long encodes (jobs die when the dyno sleeps)

Those are fine for a static demo UI, not for this media pipeline.

---

## 6. Minimal security on a public free VM

```bash
# firewall example (UFW)
sudo ufw allow OpenSSH
sudo ufw allow 3000/tcp
sudo ufw enable
```

- Prefer **Cloudflare Tunnel** or Caddy + HTTPS instead of plain HTTP on port 3000.
- Do not publish port **8765** (worker) to the internet.
- Treat uploaded media as sensitive; free VMs are shared responsibility.

---

## Quick decision

- **Only you, on this machine** → `npm run dev` (free, perfect).  
- **Need a URL others can open** → Oracle Always Free + `docker compose up`.  
- **Want Vercel** → UI only; processing must stay elsewhere (not free+perfect as one box).
