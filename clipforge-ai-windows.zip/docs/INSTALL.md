# ClipForge AI — Installation Guide

Local-first video repurposing. No Gemini, OpenAI, or paid cloud AI required.

## Requirements

| Component | Minimum | Notes |
|-----------|---------|--------|
| Node.js | 18+ | 20 LTS recommended |
| npm | 9+ | or pnpm / yarn |
| FFmpeg + FFprobe | 4.4+ | required for all media work |
| Python | 3.10+ | only for Full Local AI worker |
| RAM | 2 GB | 4+ GB if using Whisper base/small |
| Disk | 1 GB free | plus model + media space |

## 1. Install FFmpeg

### macOS
```bash
brew install ffmpeg
```

### Ubuntu / Debian
```bash
sudo apt update
sudo apt install ffmpeg
```

### Windows
```powershell
winget install ffmpeg
# or: choco install ffmpeg
```

Verify:
```bash
ffmpeg -version
ffprobe -version
```

## 2. Install the web app

```bash
git clone <your-repo-url> clipforge-ai
cd clipforge-ai
npm install
npm run setup          # readiness check
npm run test           # smoke tests
npm run dev            # http://localhost:3000
```

No API keys are required. Optional local config: copy `.env.example` to `.env.local`.

## 3. Optional — Full Local AI worker (transcription)

```bash
# System Python or a venv
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

pip install fastapi uvicorn python-multipart
pip install faster-whisper         # first run downloads the model

# Tiny model (lowest RAM) — default
export CLIPFORGE_WHISPER_SIZE=tiny
# or: base | small

npm run worker
# → http://127.0.0.1:8765/health
```

Open **Model Manager** in the UI to confirm the worker is reachable.

### Low-memory machines
```bash
export CLIPFORGE_WHISPER_SIZE=tiny
export CLIPFORGE_MAX_JOBS=1
npm run dev
```

## 4. Typical workflow

1. **Create Clips** → import a local video → **Create & Analyze**
2. Open the project → review scored candidates and transcript
3. Select clips → **Export selected** or open **Editor** for trim/captions/aspect
4. Download verified MP4 (+ optional SRT) from the Editor or `storage/exports/`

## 5. Data locations

```
storage/uploads/    # source media (originals preserved)
storage/exports/    # rendered clips
storage/temp/       # short-lived intermediates
storage/models/     # optional local model files
data/               # projects.json, jobs.json, transcripts, clips
```

Clear temp files from **Settings**.

## 6. Production-style start

```bash
npm run build
npm run start          # serves Next.js
# separate process:
npm run worker
```

Bind only to localhost unless you intentionally expose a trusted LAN. Do not expose the worker or Next.js upload APIs to the public internet without authentication and TLS.

## Troubleshooting

| Symptom | Check |
|---------|--------|
| Validate fails | `ffprobe` on PATH; file is a real video |
| Transcription placeholders | Worker offline or `faster-whisper` missing |
| Export FFmpeg error | Codecs, fonts for ASS burn-in, disk space |
| Interrupted jobs after restart | Settings → Recover interrupted jobs |
| OOM during Whisper | Use `tiny`, close other apps, `CLIPFORGE_MAX_JOBS=1` |

## Uninstall

Delete the project directory. No system services are installed by default. Remove any Python venv and Whisper cache directories you created.
