import { Library } from "lucide-react";

export default function LibraryPage() {
  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Media Library</h1>
        <p className="text-sm text-muted-foreground">
          Source videos, B-roll assets, and exported clips stored locally.
        </p>
      </div>
      <div className="rounded-lg border border-border bg-card p-12 text-center">
        <Library className="mx-auto h-12 w-12 text-muted-foreground/40" />
        <h3 className="mt-4 text-sm font-medium">Library empty</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Imported source files and user B-roll will appear here.
        </p>
      </div>
    </div>
  );
}
