"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  Loader2,
  Play,
  Search,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Film,
  Download,
} from "lucide-react";
import { formatDuration } from "@/lib/utils";
import type {
  Project,
  ClipCandidate,
  TranscriptSegment,
  Job,
} from "@/types";

export default function ProjectDetailPage() {
  const params = useParams();
  const id = params.id as string;

  const [project, setProject] = useState<Project | null>(null);
  const [transcript, setTranscript] = useState<TranscriptSegment[] | null>(null);
  const [clips, setClips] = useState<ClipCandidate[] | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"clips" | "transcript">("clips");
  const [analyzing, setAnalyzing] = useState(false);
  const [batching, setBatching] = useState(false);
  const [batchMsg, setBatchMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/projects/${id}`);
      if (!res.ok) throw new Error("Project not found");
      const data = await res.json();
      setProject(data.project);
      setTranscript(data.transcript);
      setClips(data.clips);
      setJobs(data.jobs || []);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Load failed");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  // Poll while job is running
  useEffect(() => {
    const active = jobs.find(
      (j) =>
        j.status !== "COMPLETED" &&
        j.status !== "FAILED" &&
        j.status !== "CANCELLED"
    );
    if (!active) return;
    const t = setInterval(load, 2000);
    return () => clearInterval(t);
  }, [jobs, load]);

  const rerunAnalysis = async () => {
    setAnalyzing(true);
    try {
      await fetch(`/api/projects/${id}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      await load();
    } finally {
      setAnalyzing(false);
    }
  };

  const toggleClip = async (clipId: string, selected: boolean) => {
    setClips((prev) =>
      prev
        ? prev.map((c) => (c.id === clipId ? { ...c, selected } : c))
        : prev
    );
    await fetch(`/api/projects/${id}/clips`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clipId, selected }),
    });
  };

  const batchExport = async () => {
    setBatching(true);
    setBatchMsg(null);
    try {
      const res = await fetch("/api/batch/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId: id,
          aspectRatio: project?.settings?.aspectRatio || "9:16",
          captionStyle: project?.settings?.captionStyle || "bold-social",
          burnCaptions: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Batch export failed");
      setBatchMsg(`Queued ${data.queued} export job(s) — see Export Queue`);
      await load();
    } catch (err) {
      setBatchMsg(err instanceof Error ? err.message : "Batch export failed");
    } finally {
      setBatching(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="mx-auto max-w-lg py-12 text-center">
        <AlertCircle className="mx-auto h-10 w-10 text-red-400" />
        <p className="mt-3 text-sm">{error || "Not found"}</p>
        <Link
          href="/projects"
          className="mt-4 inline-block text-sm text-violet-400 hover:underline"
        >
          Back to projects
        </Link>
      </div>
    );
  }

  const latestJob = jobs[0];
  const isRunning =
    latestJob &&
    !["COMPLETED", "FAILED", "CANCELLED"].includes(latestJob.status);

  const filteredTranscript = transcript?.filter((s) =>
    search
      ? s.text.toLowerCase().includes(search.toLowerCase())
      : true
  );

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <Link
            href="/projects"
            className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mb-2"
          >
            <ArrowLeft className="h-3 w-3" />
            Projects
          </Link>
          <h1 className="text-2xl font-semibold tracking-tight">
            {project.name}
          </h1>
          <p className="text-sm text-muted-foreground">
            {project.sourceFilename}
            {project.metadata && (
              <>
                {" · "}
                {formatDuration(project.metadata.duration)}
                {" · "}
                {project.metadata.width}×{project.metadata.height}
              </>
            )}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={batchExport}
            disabled={
              batching || !clips?.some((c) => c.selected)
            }
            className="inline-flex items-center gap-2 rounded-md bg-violet-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-50"
          >
            {batching ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Download className="h-3.5 w-3.5" />
            )}
            Export selected
          </button>
          <button
            type="button"
            onClick={rerunAnalysis}
            disabled={analyzing || !!isRunning}
            className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-1.5 text-sm hover:bg-muted disabled:opacity-50"
          >
            {analyzing || isRunning ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <RefreshCw className="h-3.5 w-3.5" />
            )}
            Re-analyze
          </button>
        </div>
        {batchMsg && (
          <p className="text-xs text-muted-foreground w-full sm:text-right">
            {batchMsg}
          </p>
        )}
      </div>

      {/* Job progress */}
      {latestJob && (
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              {latestJob.status === "COMPLETED" ? (
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              ) : latestJob.status === "FAILED" ? (
                <AlertCircle className="h-4 w-4 text-red-400" />
              ) : (
                <Loader2 className="h-4 w-4 animate-spin text-violet-400" />
              )}
              <span className="font-medium">{latestJob.status}</span>
              {latestJob.message && (
                <span className="text-muted-foreground">
                  — {latestJob.message}
                </span>
              )}
            </div>
            <span className="tabular-nums text-muted-foreground">
              {latestJob.progress}%
            </span>
          </div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-violet-500 transition-all duration-500"
              style={{ width: `${latestJob.progress}%` }}
            />
          </div>
          {latestJob.error && (
            <p className="mt-2 text-xs text-red-400">{latestJob.error}</p>
          )}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border">
        <button
          type="button"
          onClick={() => setActiveTab("clips")}
          className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${
            activeTab === "clips"
              ? "border-violet-500 text-foreground"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Clip Candidates ({clips?.length ?? 0})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("transcript")}
          className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${
            activeTab === "transcript"
              ? "border-violet-500 text-foreground"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Transcript ({transcript?.length ?? 0})
        </button>
      </div>

      {/* Clips tab */}
      {activeTab === "clips" && (
        <div className="space-y-3">
          {!clips?.length ? (
            <div className="rounded-lg border border-border bg-card p-10 text-center">
              <Film className="mx-auto h-10 w-10 text-muted-foreground/40" />
              <p className="mt-3 text-sm text-muted-foreground">
                {isRunning
                  ? "Scoring candidates…"
                  : "No clips yet. Run analysis to generate candidates."}
              </p>
            </div>
          ) : (
            clips
              .slice()
              .sort((a, b) => b.score - a.score)
              .map((clip) => (
                <div
                  key={clip.id}
                  className={`rounded-lg border bg-card p-4 transition-colors ${
                    clip.selected
                      ? "border-violet-500/50"
                      : "border-border"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      type="button"
                      onClick={() => toggleClip(clip.id, !clip.selected)}
                      className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border ${
                        clip.selected
                          ? "border-violet-500 bg-violet-500 text-white"
                          : "border-border"
                      }`}
                      aria-label={
                        clip.selected ? "Deselect clip" : "Select clip"
                      }
                    >
                      {clip.selected && (
                        <CheckCircle2 className="h-3.5 w-3.5" />
                      )}
                    </button>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium text-sm">
                          {clip.title || "Untitled clip"}
                        </span>
                        <span className="rounded bg-violet-500/15 px-1.5 py-0.5 text-xs font-medium text-violet-300 tabular-nums">
                          {clip.score}
                        </span>
                        <span className="text-xs text-muted-foreground tabular-nums">
                          {formatDuration(clip.start)} –{" "}
                          {formatDuration(clip.end)} (
                          {formatDuration(clip.end - clip.start)})
                        </span>
                      </div>
                      {clip.summary && (
                        <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                          {clip.summary}
                        </p>
                      )}
                      {clip.scoreBreakdown && (
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {Object.entries(clip.scoreBreakdown)
                            .filter(
                              ([k]) =>
                                !k.includes("Penalty") ||
                                (clip.scoreBreakdown?.[k] ?? 0) > 0
                            )
                            .slice(0, 6)
                            .map(([k, v]) => (
                              <span
                                key={k}
                                className="rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground"
                              >
                                {k.replace(/([A-Z])/g, " $1").trim()}: {v}
                              </span>
                            ))}
                        </div>
                      )}
                    </div>
                    <Link
                      href={`/editor?project=${id}&clip=${clip.id}`}
                      className="inline-flex items-center gap-1 rounded-md border border-border px-2.5 py-1 text-xs hover:bg-muted"
                    >
                      <Play className="h-3 w-3" />
                      Edit
                    </Link>
                  </div>
                </div>
              ))
          )}
        </div>
      )}

      {/* Transcript tab */}
      {activeTab === "transcript" && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[12rem]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="search"
                placeholder="Search transcript…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-md border border-border bg-background py-2 pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
              />
            </div>
            {transcript && transcript.length > 0 && (
              <>
                <a
                  href={`/api/projects/${id}/transcript?format=srt`}
                  className="rounded-md border border-border px-2.5 py-1.5 text-xs hover:bg-muted"
                  download
                >
                  Export SRT
                </a>
                <a
                  href={`/api/projects/${id}/transcript?format=vtt`}
                  className="rounded-md border border-border px-2.5 py-1.5 text-xs hover:bg-muted"
                  download
                >
                  Export VTT
                </a>
              </>
            )}
          </div>
          {!filteredTranscript?.length ? (
            <div className="rounded-lg border border-border bg-card p-10 text-center text-sm text-muted-foreground">
              {isRunning
                ? "Transcribing…"
                : "No transcript available. Install faster-whisper and re-analyze for real speech-to-text."}
            </div>
          ) : (
            <div className="max-h-[28rem] space-y-1 overflow-y-auto rounded-lg border border-border bg-card p-3">
              {filteredTranscript.map((seg) => (
                <div
                  key={seg.id}
                  className="group flex gap-3 rounded-md px-2 py-1.5 text-sm hover:bg-muted/50"
                >
                  <span className="shrink-0 tabular-nums text-xs text-muted-foreground pt-0.5 w-20">
                    {formatDuration(seg.start)}
                  </span>
                  <input
                    type="text"
                    defaultValue={seg.text}
                    className="min-w-0 flex-1 bg-transparent text-foreground/90 outline-none focus:underline"
                    onBlur={async (e) => {
                      const next = e.target.value;
                      if (next === seg.text || !transcript) return;
                      const updated = transcript.map((s) =>
                        s.id === seg.id ? { ...s, text: next } : s
                      );
                      setTranscript(updated);
                      await fetch(`/api/projects/${id}/transcript`, {
                        method: "PUT",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ segments: updated }),
                      });
                    }}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
