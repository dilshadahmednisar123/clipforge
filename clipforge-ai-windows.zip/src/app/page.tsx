import Link from "next/link";
import {
  FolderOpen,
  Film,
  Download,
  Activity,
  Plus,
  HardDrive,
  Cpu,
} from "lucide-react";
import { formatBytes } from "@/lib/utils";

// In a real app these would come from SQLite / API
const stats = {
  projects: 0,
  sources: 0,
  clips: 0,
  exports: 0,
  activeJobs: 0,
  storageUsed: 0,
};

export default function DashboardPage() {
  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            Local-first AI video repurposing. No cloud required.
          </p>
        </div>
        <Link
          href="/create"
          className="inline-flex items-center gap-2 rounded-md bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500 transition-colors"
        >
          <Plus className="h-4 w-4" />
          New Project
        </Link>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Projects"
          value={stats.projects}
          icon={FolderOpen}
          href="/projects"
        />
        <StatCard
          title="Source Videos"
          value={stats.sources}
          icon={Film}
          href="/library"
        />
        <StatCard
          title="Generated Clips"
          value={stats.clips}
          icon={Activity}
          href="/projects"
        />
        <StatCard
          title="Exports"
          value={stats.exports}
          icon={Download}
          href="/exports"
        />
      </div>

      {/* System status */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-lg border border-border bg-card p-5">
          <h2 className="mb-4 text-sm font-medium text-muted-foreground">
            System Status
          </h2>
          <div className="space-y-3">
            <StatusRow
              label="FFmpeg / FFprobe"
              status="checking"
              detail="Required for all media operations"
            />
            <StatusRow
              label="Processing Worker"
              status="unavailable"
              detail="Start with: npm run worker"
            />
            <StatusRow
              label="Whisper Model"
              status="unavailable"
              detail="Install via Model Manager for offline transcription"
            />
            <StatusRow
              label="Storage"
              status="ok"
              detail={`${formatBytes(stats.storageUsed)} used`}
            />
          </div>
        </div>

        <div className="rounded-lg border border-border bg-card p-5">
          <h2 className="mb-4 text-sm font-medium text-muted-foreground">
            Getting Started
          </h2>
          <ol className="space-y-3 text-sm">
            <li className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-violet-600/20 text-xs font-medium text-violet-400">
                1
              </span>
              <div>
                <div className="font-medium">Check system readiness</div>
                <div className="text-muted-foreground">
                  Run <code className="rounded bg-muted px-1 text-xs">npm run setup</code> or
                  open Model Manager
                </div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-violet-600/20 text-xs font-medium text-violet-400">
                2
              </span>
              <div>
                <div className="font-medium">Import a video</div>
                <div className="text-muted-foreground">
                  Go to Create Clips and select a local media file
                </div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-violet-600/20 text-xs font-medium text-violet-400">
                3
              </span>
              <div>
                <div className="font-medium">Generate & edit clips</div>
                <div className="text-muted-foreground">
                  Review scored candidates, adjust captions, export
                </div>
              </div>
            </li>
          </ol>
        </div>
      </div>

      {/* Empty recent projects */}
      <div className="rounded-lg border border-border bg-card p-8 text-center">
        <FolderOpen className="mx-auto h-10 w-10 text-muted-foreground/50" />
        <h3 className="mt-3 text-sm font-medium">No projects yet</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Import a video to create your first project and start generating clips.
        </p>
        <Link
          href="/create"
          className="mt-4 inline-flex items-center gap-2 rounded-md border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-muted transition-colors"
        >
          <Plus className="h-4 w-4" />
          Create first project
        </Link>
      </div>
    </div>
  );
}

function StatCard({
  title,
  value,
  icon: Icon,
  href,
}: {
  title: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
}) {
  return (
    <Link
      href={href}
      className="rounded-lg border border-border bg-card p-4 transition-colors hover:border-violet-500/40"
    >
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{title}</span>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="mt-2 text-2xl font-semibold tabular-nums">{value}</div>
    </Link>
  );
}

function StatusRow({
  label,
  status,
  detail,
}: {
  label: string;
  status: "ok" | "checking" | "unavailable" | "error";
  detail: string;
}) {
  const colors = {
    ok: "bg-emerald-400",
    checking: "bg-amber-400 animate-pulse",
    unavailable: "bg-muted-foreground/40",
    error: "bg-red-400",
  };
  return (
    <div className="flex items-start gap-3">
      <span
        className={`mt-1.5 inline-block h-2 w-2 shrink-0 rounded-full ${colors[status]}`}
      />
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{detail}</div>
      </div>
    </div>
  );
}
