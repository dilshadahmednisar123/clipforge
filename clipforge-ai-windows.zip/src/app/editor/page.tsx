"use client";

import { useEffect, useState, useCallback, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  Loader2,
  Download,
  Scissors,
  Type,
  Ratio,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
} from "lucide-react";
import { formatDuration, formatBytes } from "@/lib/utils";
import type { Project, ClipCandidate, TranscriptSegment } from "@/types";

const ASPECTS = [
  { id: "9:16", label: "9:16 Vertical" },
  { id: "1:1", label: "1:1 Square" },
  { id: "4:5", label: "4:5 Portrait" },
  { id: "16:9", label: "16:9 Landscape" },
] as const;

const CAPTION_STYLES = [
  { id: "minimal-clean", label: "Minimal Clean" },
  { id: "bold-social", label: "Bold Social" },
  { id: "karaoke", label: "Karaoke" },
  { id: "word-emphasis", label: "Word Emphasis" },
  { id: "creator-podcast", label: "Creator / Podcast" },
  { id: "high-contrast", label: "High Contrast" },
];

function EditorInner() {
  const searchParams = useSearchParams();
  const projectId = searchParams.get("project") || "";
  const clipId = searchParams.get("clip") || "";

  const [project, setProject] = useState<Project | null>(null);
  const [clip, setClip] = useState<ClipCandidate | null>(null);
  const [transcript, setTranscript] = useState<TranscriptSegment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [start, setStart] = useState(0);
  const [end, setEnd] = useState(30);
  const [aspect, setAspect] = useState<string>("9:16");
  const [captionStyle, setCaptionStyle] = useState("bold-social");
  const [burnCaptions, setBurnCaptions] = useState(true);
  const [loudnorm, setLoudnorm] = useState(true);
  const [focalX, setFocalX] = useState(0.5);
  const [focalY, setFocalY] = useState(0.5);

  const [exporting, setExporting] = useState(false);
  const [exportResult, setExportResult] = useState<{
    ok: boolean;
    downloadUrl?: string;
    srtUrl?: string;
    filename?: string;
    size?: number;
    width?: number;
    height?: number;
    duration?: number;
    filterNote?: string;
    error?: string;
  } | null>(null);

  const load = useCallback(async () => {
    if (!projectId) {
      setLoading(false);
      return;
    }
    try {
      const res = await fetch(`/api/projects/${projectId}`);
      if (!res.ok) throw new Error("Project not found");
      const data = await res.json();
      setProject(data.project);
      setTranscript(data.transcript || []);
      const clips: ClipCandidate[] = data.clips || [];
      const c = clipId
        ? clips.find((x) => x.id === clipId) || clips[0]
        : clips.find((x) => x.selected) || clips[0];
      if (c) {
        setClip(c);
        setStart(c.start);
        setEnd(c.end);
        if (c.aspectRatio) setAspect(c.aspectRatio);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Load failed");
    } finally {
      setLoading(false);
    }
  }, [projectId, clipId]);

  useEffect(() => {
    load();
  }, [load]);

  const saveTrim = async () => {
    if (!projectId || !clip) return;
    await fetch(`/api/projects/${projectId}/clips`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        clipId: clip.id,
        start,
        end,
        aspectRatio: aspect,
      }),
    });
    setClip({ ...clip, start, end, aspectRatio: aspect });
  };

  const runExport = async () => {
    if (!projectId || !clip) return;
    setExporting(true);
    setExportResult(null);
    try {
      await saveTrim();
      const res = await fetch("/api/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId,
          clipId: clip.id,
          aspectRatio: aspect,
          captionStyle,
          burnCaptions,
          focalX,
          focalY,
          start,
          end,
          audio: loudnorm
            ? { loudnorm: true, targetLufs: -14, fadeIn: 0.15, fadeOut: 0.2 }
            : { fadeIn: 0.1, fadeOut: 0.15 },
        }),
      });
      const data = await res.json();
      setExportResult(data);
    } catch (err) {
      setExportResult({
        ok: false,
        error: err instanceof Error ? err.message : "Export failed",
      });
    } finally {
      setExporting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!projectId) {
    return (
      <div className="mx-auto max-w-lg py-16 text-center">
        <Scissors className="mx-auto h-10 w-10 text-muted-foreground/40" />
        <h2 className="mt-4 text-sm font-medium">No clip selected</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Open a project, generate candidates, then click Edit on a clip.
        </p>
        <Link
          href="/projects"
          className="mt-4 inline-block text-sm text-violet-400 hover:underline"
        >
          Go to projects
        </Link>
      </div>
    );
  }

  if (error || !project || !clip) {
    return (
      <div className="mx-auto max-w-lg py-12 text-center">
        <AlertCircle className="mx-auto h-10 w-10 text-red-400" />
        <p className="mt-3 text-sm">{error || "Clip not found"}</p>
        <Link
          href={projectId ? `/projects/${projectId}` : "/projects"}
          className="mt-4 inline-block text-sm text-violet-400 hover:underline"
        >
          Back
        </Link>
      </div>
    );
  }

  const duration = Math.max(0, end - start);
  const srcDur = project.metadata?.duration || end;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <Link
            href={`/projects/${projectId}`}
            className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mb-1"
          >
            <ArrowLeft className="h-3 w-3" />
            {project.name}
          </Link>
          <h1 className="text-xl font-semibold tracking-tight">
            {clip.title || "Clip Editor"}
          </h1>
          <p className="text-sm text-muted-foreground">
            Score {clip.score} · Source{" "}
            {project.metadata
              ? `${project.metadata.width}×${project.metadata.height}`
              : "—"}
          </p>
        </div>
        <button
          type="button"
          onClick={runExport}
          disabled={exporting || duration < 0.5}
          className="inline-flex items-center gap-2 rounded-md bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-50"
        >
          {exporting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Rendering…
            </>
          ) : (
            <>
              <Download className="h-4 w-4" />
              Export clip
            </>
          )}
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <div className="lg:col-span-3 space-y-4">
          <div className="relative aspect-[9/16] max-h-[420px] mx-auto w-full max-w-[280px] rounded-lg border border-border bg-black overflow-hidden">
            {exportResult?.ok && exportResult.downloadUrl ? (
              <video
                key={exportResult.downloadUrl}
                src={exportResult.downloadUrl}
                controls
                className="h-full w-full object-contain"
              />
            ) : projectId ? (
              <video
                key={`${projectId}-${start}`}
                src={`/api/media/stream?projectId=${encodeURIComponent(projectId)}`}
                controls
                className="h-full w-full object-contain"
                onLoadedMetadata={(e) => {
                  const v = e.currentTarget;
                  if (start > 0 && start < (v.duration || Infinity)) {
                    v.currentTime = start;
                  }
                }}
              />
            ) : (
              <div className="flex h-full flex-col items-center justify-center p-4 text-center">
                <Ratio className="h-8 w-8 text-muted-foreground/50" />
                <p className="mt-2 text-xs text-muted-foreground">
                  {aspect} · {formatDuration(duration)}
                </p>
              </div>
            )}
          </div>
          <p className="text-center text-[10px] text-muted-foreground">
            {exportResult?.ok
              ? "Exported output"
              : "Source preview (seek to trim start)"}
          </p>

          <div className="rounded-lg border border-border bg-card p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Scissors className="h-4 w-4" />
              Trim
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">Start (s)</label>
                <input
                  type="number"
                  step={0.1}
                  min={0}
                  max={srcDur}
                  value={start}
                  onChange={(e) => setStart(Number(e.target.value))}
                  className="mt-1 w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">End (s)</label>
                <input
                  type="number"
                  step={0.1}
                  min={0}
                  max={srcDur}
                  value={end}
                  onChange={(e) => setEnd(Number(e.target.value))}
                  className="mt-1 w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm tabular-nums"
                />
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">
                Range on source timeline
              </label>
              <div className="mt-1.5 relative h-8 rounded bg-muted">
                <div
                  className="absolute top-0 bottom-0 rounded bg-violet-500/40 border border-violet-500/60"
                  style={{
                    left: `${Math.min(100, (start / srcDur) * 100)}%`,
                    width: `${Math.min(100, (duration / srcDur) * 100)}%`,
                  }}
                />
              </div>
              <div className="mt-1 flex justify-between text-[10px] text-muted-foreground tabular-nums">
                <span>0:00</span>
                <span>{formatDuration(duration)} selected</span>
                <span>{formatDuration(srcDur)}</span>
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-border bg-card p-4">
            <div className="text-sm font-medium mb-2">Transcript in range</div>
            <div className="max-h-36 overflow-y-auto space-y-1 text-sm text-muted-foreground">
              {transcript
                .filter((s) => s.end > start && s.start < end)
                .map((s) => (
                  <div key={s.id} className="flex gap-2">
                    <span className="shrink-0 tabular-nums text-xs w-12">
                      {formatDuration(s.start)}
                    </span>
                    <span>{s.text}</span>
                  </div>
                ))}
              {!transcript.some((s) => s.end > start && s.start < end) && (
                <p className="text-xs">No transcript segments in this range.</p>
              )}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <div className="rounded-lg border border-border bg-card p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Ratio className="h-4 w-4" />
              Aspect ratio
            </div>
            <div className="grid grid-cols-2 gap-2">
              {ASPECTS.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => setAspect(a.id)}
                  className={`rounded-md border px-2 py-2 text-xs font-medium transition-colors ${
                    aspect === a.id
                      ? "border-violet-500 bg-violet-500/15 text-violet-200"
                      : "border-border hover:bg-muted"
                  }`}
                >
                  {a.label}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-lg border border-border bg-card p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Type className="h-4 w-4" />
              Captions
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={burnCaptions}
                onChange={(e) => setBurnCaptions(e.target.checked)}
                className="rounded border-border"
              />
              Burn captions into video
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={loudnorm}
                onChange={(e) => setLoudnorm(e.target.checked)}
                className="rounded border-border"
              />
              Loudness normalize (−14 LUFS)
            </label>
            <select
              value={captionStyle}
              onChange={(e) => setCaptionStyle(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm"
            >
              {CAPTION_STYLES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>

          <div className="rounded-lg border border-border bg-card p-4 space-y-3">
            <div className="text-sm font-medium">Focal point (crop)</div>
            <p className="text-xs text-muted-foreground">
              Without a face-tracking model, crop is centered on this point.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">X (0–1)</label>
                <input
                  type="number"
                  step={0.05}
                  min={0}
                  max={1}
                  value={focalX}
                  onChange={(e) => setFocalX(Number(e.target.value))}
                  className="mt-1 w-full rounded-md border border-border bg-background px-2 py-1 text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Y (0–1)</label>
                <input
                  type="number"
                  step={0.05}
                  min={0}
                  max={1}
                  value={focalY}
                  onChange={(e) => setFocalY(Number(e.target.value))}
                  className="mt-1 w-full rounded-md border border-border bg-background px-2 py-1 text-sm"
                />
              </div>
            </div>
          </div>

          {exportResult && (
            <div
              className={`rounded-lg border p-4 text-sm ${
                exportResult.ok
                  ? "border-emerald-500/30 bg-emerald-500/5"
                  : "border-red-500/30 bg-red-500/5"
              }`}
            >
              {exportResult.ok ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 font-medium text-emerald-400">
                    <CheckCircle2 className="h-4 w-4" />
                    Export verified
                  </div>
                  <dl className="grid grid-cols-2 gap-1 text-muted-foreground">
                    <dt>File</dt>
                    <dd className="text-foreground truncate">
                      {exportResult.filename}
                    </dd>
                    {exportResult.width && (
                      <>
                        <dt>Resolution</dt>
                        <dd className="text-foreground">
                          {exportResult.width}×{exportResult.height}
                        </dd>
                      </>
                    )}
                    {exportResult.duration != null && (
                      <>
                        <dt>Duration</dt>
                        <dd className="text-foreground">
                          {formatDuration(exportResult.duration)}
                        </dd>
                      </>
                    )}
                    {exportResult.size != null && (
                      <>
                        <dt>Size</dt>
                        <dd className="text-foreground">
                          {formatBytes(exportResult.size)}
                        </dd>
                      </>
                    )}
                    {exportResult.filterNote && (
                      <>
                        <dt>Crop</dt>
                        <dd className="text-foreground">
                          {exportResult.filterNote}
                        </dd>
                      </>
                    )}
                  </dl>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {exportResult.downloadUrl && (
                      <a
                        href={exportResult.downloadUrl}
                        download
                        className="inline-flex items-center gap-1.5 rounded-md bg-violet-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-violet-500"
                      >
                        <Download className="h-3 w-3" />
                        Download MP4
                      </a>
                    )}
                    {exportResult.srtUrl && (
                      <a
                        href={exportResult.srtUrl}
                        download
                        className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs hover:bg-muted"
                      >
                        Download SRT
                      </a>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-2 text-red-400">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{exportResult.error}</span>
                </div>
              )}
            </div>
          )}

          <button
            type="button"
            onClick={saveTrim}
            className="w-full inline-flex items-center justify-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:bg-muted"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Save trim & settings
          </button>
        </div>
      </div>
    </div>
  );
}

export default function EditorPage() {
  return (
    <Suspense
      fallback={
        <div className="flex justify-center py-20">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      }
    >
      <EditorInner />
    </Suspense>
  );
}
