"use client";

import { useEffect, useState } from "react";
import {
  Cpu,
  Download,
  HardDrive,
  AlertTriangle,
  CheckCircle2,
  Loader2,
} from "lucide-react";

interface WorkerInfo {
  reachable: boolean;
  whisper?: boolean;
  whisper_size?: string;
  whisper_error?: string;
  ffmpeg?: boolean;
  message?: string;
}

const models = [
  {
    id: "whisper-tiny",
    name: "Whisper Tiny",
    size: "~75 MB",
    description: "Fastest, lowest memory (~1 GB RAM). Good for clear speech.",
    env: "tiny",
  },
  {
    id: "whisper-base",
    name: "Whisper Base",
    size: "~145 MB",
    description: "Balanced accuracy / speed. Recommended starting point.",
    env: "base",
  },
  {
    id: "whisper-small",
    name: "Whisper Small",
    size: "~465 MB",
    description: "Higher accuracy. Needs more RAM (~2 GB+).",
    env: "small",
  },
];

export default function ModelsPage() {
  const [worker, setWorker] = useState<WorkerInfo | null>(null);
  const [localModels, setLocalModels] = useState<
    Array<{ name: string; size: number }>
  >([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/worker/health")
        .then((r) => r.json())
        .catch(() => ({ reachable: false, message: "Request failed" })),
      fetch("/api/system/storage")
        .then((r) => r.json())
        .catch(() => ({ models: [] })),
    ]).then(([w, s]) => {
      setWorker(w);
      setLocalModels(s.models || []);
    }).finally(() => setLoading(false));
  }, []);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Model Manager</h1>
        <p className="text-sm text-muted-foreground">
          Local open-source models only. Nothing downloads without your consent.
        </p>
      </div>

      <div className="rounded-lg border border-border bg-card p-4">
        <h2 className="text-sm font-medium mb-3">Worker status</h2>
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Checking…
          </div>
        ) : worker?.reachable ? (
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2 text-emerald-400">
              <CheckCircle2 className="h-4 w-4" />
              Worker reachable
            </div>
            <div className="text-muted-foreground">
              FFmpeg: {worker.ffmpeg ? "yes" : "no"} · Whisper:{" "}
              {worker.whisper
                ? `yes (${worker.whisper_size || "loaded"})`
                : worker.whisper_error || "not installed"}
            </div>
          </div>
        ) : (
          <div className="flex gap-3 text-sm">
            <AlertTriangle className="h-5 w-5 shrink-0 text-amber-400" />
            <div>
              <div className="font-medium text-amber-200">Worker offline</div>
              <p className="mt-1 text-muted-foreground">
                {worker?.message || "Not reachable at http://127.0.0.1:8765"}
              </p>
              <pre className="mt-2 rounded bg-muted p-2 text-xs overflow-x-auto">
{`pip install fastapi uvicorn python-multipart
# optional for real STT:
pip install faster-whisper

npm run worker`}
              </pre>
            </div>
          </div>
        )}
      </div>

      <div className="space-y-3">
        {models.map((m) => (
          <div
            key={m.id}
            className="flex items-start gap-4 rounded-lg border border-border bg-card p-4"
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-muted">
              <Cpu className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-medium">{m.name}</span>
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <HardDrive className="h-3 w-3" />
                  {m.size}
                </span>
              </div>
              <p className="mt-0.5 text-sm text-muted-foreground">
                {m.description}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Set{" "}
                <code className="rounded bg-muted px-1">
                  CLIPFORGE_WHISPER_SIZE={m.env}
                </code>{" "}
                before starting the worker. First transcribe downloads the model.
              </p>
            </div>
            <button
              type="button"
              disabled
              className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-sm text-muted-foreground opacity-60 cursor-not-allowed"
              title="Managed by faster-whisper on first transcribe"
            >
              <Download className="h-3.5 w-3.5" />
              Via worker
            </button>
          </div>
        ))}
      </div>

      <div className="rounded-lg border border-border bg-card p-4">
        <h2 className="text-sm font-medium mb-2">Files in storage/models</h2>
        {!localModels.length ? (
          <p className="text-xs text-muted-foreground">
            No local model files yet. faster-whisper caches downloads on first
            use (often under the user home cache, not this folder).
          </p>
        ) : (
          <ul className="space-y-1 text-sm">
            {localModels.map((m) => (
              <li key={m.name} className="flex justify-between gap-2">
                <span className="truncate text-muted-foreground">{m.name}</span>
                <span className="tabular-nums shrink-0">
                  {(m.size / (1024 * 1024)).toFixed(1)} MB
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
