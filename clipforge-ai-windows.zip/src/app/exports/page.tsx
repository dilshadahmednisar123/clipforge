"use client";

import { useEffect, useState, useCallback } from "react";
import { Download, Loader2, Film, XCircle, RotateCcw } from "lucide-react";
import { formatRelativeTime } from "@/lib/utils";

interface JobRow {
  id: string;
  projectId: string;
  type: string;
  status: string;
  progress: number;
  message?: string;
  error?: string;
  createdAt: string;
}

export default function ExportsPage() {
  const [jobs, setJobs] = useState<JobRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(() => {
    fetch("/api/queue")
      .then((r) => r.json())
      .then((d) => setJobs(d.recent || []))
      .catch(() => setJobs([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 2500);
    return () => clearInterval(t);
  }, [load]);

  const act = async (id: string, action: "cancel" | "retry") => {
    setBusyId(id);
    try {
      await fetch(`/api/jobs/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      load();
    } finally {
      setBusyId(null);
    }
  };

  const isActive = (s: string) =>
    s !== "COMPLETED" && s !== "FAILED" && s !== "CANCELLED";

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Export Queue</h1>
        <p className="text-sm text-muted-foreground">
          Background jobs with cancel and retry. Finished files are under{" "}
          <code className="text-xs">storage/exports/</code>.
        </p>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : !jobs.length ? (
        <div className="rounded-lg border border-border bg-card p-12 text-center">
          <Download className="mx-auto h-12 w-12 text-muted-foreground/40" />
          <h3 className="mt-4 text-sm font-medium">No jobs yet</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Analyze a project or export clips from the Editor. Batch export
            queues multiple render jobs.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {jobs.map((j) => (
            <div
              key={j.id}
              className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card p-3 text-sm"
            >
              <Film className="h-4 w-4 shrink-0 text-muted-foreground" />
              <div className="min-w-0 flex-1">
                <div className="font-medium truncate">
                  {j.type} · {j.status}
                </div>
                <div className="text-xs text-muted-foreground">
                  {j.error || j.message || "—"} ·{" "}
                  {formatRelativeTime(j.createdAt)}
                </div>
                {isActive(j.status) && (
                  <div className="mt-1.5 h-1 max-w-xs overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-violet-500 transition-all"
                      style={{ width: `${j.progress}%` }}
                    />
                  </div>
                )}
              </div>
              <span className="tabular-nums text-xs text-muted-foreground">
                {j.progress}%
              </span>
              <div className="flex gap-1">
                {isActive(j.status) && (
                  <button
                    type="button"
                    title="Cancel"
                    disabled={busyId === j.id}
                    onClick={() => act(j.id, "cancel")}
                    className="rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-red-400 disabled:opacity-50"
                  >
                    <XCircle className="h-4 w-4" />
                  </button>
                )}
                {(j.status === "FAILED" || j.status === "CANCELLED") && (
                  <button
                    type="button"
                    title="Retry"
                    disabled={busyId === j.id}
                    onClick={() => act(j.id, "retry")}
                    className="rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-violet-400 disabled:opacity-50"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
