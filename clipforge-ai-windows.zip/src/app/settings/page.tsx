"use client";

import { useEffect, useState } from "react";
import { Loader2, Trash2, RefreshCw, HardDrive } from "lucide-react";
import { formatBytes } from "@/lib/utils";

interface StorageData {
  totalBytes: number;
  breakdown: Record<string, number>;
}

interface QueueStats {
  maxConcurrent: number;
  active: number;
  queued: number;
}

export default function SettingsPage() {
  const [storage, setStorage] = useState<StorageData | null>(null);
  const [queue, setQueue] = useState<QueueStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [clearing, setClearing] = useState(false);
  const [recovering, setRecovering] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    Promise.all([
      fetch("/api/system/storage").then((r) => r.json()),
      fetch("/api/queue").then((r) => r.json()),
    ])
      .then(([s, q]) => {
        setStorage(s);
        setQueue(q.stats || null);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const clearTemp = async () => {
    setClearing(true);
    setMessage(null);
    try {
      const res = await fetch("/api/system/storage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "clear-temp" }),
      });
      const data = await res.json();
      setMessage(
        `Removed ${data.removed || 0} temp items (${formatBytes(data.bytes || 0)})`
      );
      load();
    } catch {
      setMessage("Failed to clear temp files");
    } finally {
      setClearing(false);
    }
  };

  const recover = async () => {
    setRecovering(true);
    setMessage(null);
    try {
      const res = await fetch("/api/system/recover", { method: "POST" });
      const data = await res.json();
      setMessage(
        data.recovered
          ? `Marked ${data.recovered} interrupted job(s) as failed — use Retry on the project or Export Queue`
          : "No interrupted jobs found"
      );
    } catch {
      setMessage("Recovery request failed");
    } finally {
      setRecovering(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Local preferences. No account required.
        </p>
      </div>

      {message && (
        <div className="rounded-md border border-border bg-muted/40 px-3 py-2 text-sm">
          {message}
        </div>
      )}

      <section className="rounded-lg border border-border bg-card p-5 space-y-4">
        <h2 className="text-sm font-medium flex items-center gap-2">
          <HardDrive className="h-4 w-4" />
          Storage
        </h2>
        {loading || !storage ? (
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        ) : (
          <>
            <p className="text-sm">
              Total used:{" "}
              <span className="font-medium tabular-nums">
                {formatBytes(storage.totalBytes)}
              </span>
            </p>
            <dl className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
              {Object.entries(storage.breakdown || {}).map(([k, v]) => (
                <div key={k} className="flex justify-between gap-2">
                  <dt className="capitalize">{k}</dt>
                  <dd className="tabular-nums text-foreground">
                    {formatBytes(v)}
                  </dd>
                </div>
              ))}
            </dl>
            <button
              type="button"
              onClick={clearTemp}
              disabled={clearing}
              className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-1.5 text-sm hover:bg-muted disabled:opacity-50"
            >
              {clearing ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Trash2 className="h-3.5 w-3.5" />
              )}
              Clear temporary files
            </button>
          </>
        )}
      </section>

      <section className="rounded-lg border border-border bg-card p-5 space-y-4">
        <h2 className="text-sm font-medium">Job queue</h2>
        {queue && (
          <p className="text-sm text-muted-foreground">
            Active: {queue.active} / {queue.maxConcurrent} · Queued:{" "}
            {queue.queued}
          </p>
        )}
        <p className="text-xs text-muted-foreground">
          Set <code className="rounded bg-muted px-1">CLIPFORGE_MAX_JOBS</code>{" "}
          to change concurrency (default 1).
        </p>
        <button
          type="button"
          onClick={recover}
          disabled={recovering}
          className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-1.5 text-sm hover:bg-muted disabled:opacity-50"
        >
          {recovering ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <RefreshCw className="h-3.5 w-3.5" />
          )}
          Recover interrupted jobs
        </button>
      </section>

      <section className="rounded-lg border border-border bg-card p-5 space-y-2">
        <h2 className="text-sm font-medium">About</h2>
        <p className="text-sm text-muted-foreground">
          ClipForge AI v0.6.0 — Phases 1–6. Local-first, no paid AI APIs.
        </p>
      </section>
    </div>
  );
}
