import { NextRequest, NextResponse } from "next/server";
import {
  getProject,
  getTranscript,
  getClips,
  updateClip,
  updateProject,
  createJob,
  setJobStatus,
} from "@/lib/db/store";
import { renderClip } from "@/lib/export/render";
import type { AspectRatio } from "@/lib/reframe/crop";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      projectId,
      clipId,
      aspectRatio = "9:16",
      captionStyle = "bold-social",
      burnCaptions = true,
      focalX,
      focalY,
      start: overrideStart,
      end: overrideEnd,
      audio,
    } = body;

    if (!projectId || !clipId) {
      return NextResponse.json(
        { error: "projectId and clipId required" },
        { status: 400 }
      );
    }

    const project = await getProject(projectId);
    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 });
    }

    const clips = (await getClips(projectId)) || [];
    const clip = clips.find((c) => c.id === clipId);
    if (!clip) {
      return NextResponse.json({ error: "Clip not found" }, { status: 404 });
    }

    const start = typeof overrideStart === "number" ? overrideStart : clip.start;
    const end = typeof overrideEnd === "number" ? overrideEnd : clip.end;

    const segments = (await getTranscript(projectId)) || [];
    const meta = project.metadata;

    const job = await createJob({ projectId, type: "export" });
    await setJobStatus(job.id, "RENDERING", {
      progress: 10,
      message: "Rendering clip…",
      startedAt: new Date().toISOString(),
    });

    const result = await renderClip({
      sourcePath: project.sourcePath,
      start,
      end,
      aspectRatio: aspectRatio as AspectRatio,
      srcWidth: meta?.width || 1920,
      srcHeight: meta?.height || 1080,
      captionStyle,
      burnCaptions,
      segments,
      focalX,
      focalY,
      audio,
      outputName: `${project.name.slice(0, 40)}_${clipId.slice(0, 6)}`,
    });

    if (!result.ok) {
      await setJobStatus(job.id, "FAILED", {
        progress: 0,
        error: result.error,
        finishedAt: new Date().toISOString(),
      });
      return NextResponse.json(
        { ok: false, error: result.error, jobId: job.id },
        { status: 500 }
      );
    }

    await updateClip(projectId, clipId, {
      exportPath: result.outputPath,
      aspectRatio,
      start,
      end,
    });

    await setJobStatus(job.id, "COMPLETED", {
      progress: 100,
      message: "Export verified",
      finishedAt: new Date().toISOString(),
    });

    await updateProject(projectId, {
      exportCount: (project.exportCount || 0) + 1,
    });

    return NextResponse.json({
      ok: true,
      jobId: job.id,
      filename: result.filename,
      duration: result.duration,
      width: result.width,
      height: result.height,
      size: result.size,
      filterNote: result.filterNote,
      downloadUrl: `/api/export/download?file=${encodeURIComponent(result.filename!)}`,
      srtUrl: result.srtPath
        ? `/api/export/download?file=${encodeURIComponent(result.filename!.replace(/\.mp4$/, ".srt"))}`
        : undefined,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Export failed";
    console.error("[export]", message);
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
