import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import {
  downloadBasename,
  resolveUnderRoot,
} from "@/lib/security/paths";

const EXPORT_DIR = path.join(process.cwd(), "storage", "exports");

export async function GET(req: NextRequest) {
  const file = req.nextUrl.searchParams.get("file");
  if (!file) {
    return NextResponse.json({ error: "file required" }, { status: 400 });
  }

  const base = downloadBasename(file);
  if (!base) {
    return NextResponse.json({ error: "Invalid filename" }, { status: 400 });
  }

  const full = resolveUnderRoot(EXPORT_DIR, base);
  if (!full) {
    return NextResponse.json({ error: "Invalid path" }, { status: 400 });
  }

  try {
    const data = await fs.readFile(full);
    const ext = path.extname(base).toLowerCase();
    const types: Record<string, string> = {
      ".mp4": "video/mp4",
      ".srt": "application/x-subrip",
      ".vtt": "text/vtt",
      ".ass": "text/x-ssa",
    };
    const contentType = types[ext] || "application/octet-stream";

    return new NextResponse(data, {
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${base}"`,
        "Content-Length": String(data.length),
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }
}
