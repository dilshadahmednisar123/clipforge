import { NextRequest, NextResponse } from "next/server";
import { getProject, getTranscript, saveTranscript } from "@/lib/db/store";
import {
  generateSRT,
  generateVTT,
  getStyle,
} from "@/lib/captions/generator";
import type { TranscriptSegment } from "@/types";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const project = await getProject(id);
  if (!project) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const segments = (await getTranscript(id)) || [];
  const format = (req.nextUrl.searchParams.get("format") || "json").toLowerCase();
  const style = getStyle("bold-social");

  if (format === "srt") {
    const body = generateSRT(segments, style);
    return new NextResponse(body, {
      headers: {
        "Content-Type": "application/x-subrip; charset=utf-8",
        "Content-Disposition": `attachment; filename="${sanitize(project.name)}.srt"`,
      },
    });
  }

  if (format === "vtt") {
    const body = generateVTT(segments, style);
    return new NextResponse(body, {
      headers: {
        "Content-Type": "text/vtt; charset=utf-8",
        "Content-Disposition": `attachment; filename="${sanitize(project.name)}.vtt"`,
      },
    });
  }

  return NextResponse.json({ segments });
}

/** Update transcript segments (corrections from editor). */
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const project = await getProject(id);
  if (!project) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const body = await req.json();
  const segments = body.segments as TranscriptSegment[];
  if (!Array.isArray(segments)) {
    return NextResponse.json({ error: "segments array required" }, { status: 400 });
  }

  // Basic validation — preserve timing structure
  const cleaned = segments
    .filter((s) => s && typeof s.text === "string")
    .map((s, i) => ({
      id: s.id || `seg-${i}`,
      start: Number(s.start) || 0,
      end: Number(s.end) || 0,
      text: String(s.text).slice(0, 5000),
      speaker: s.speaker,
      words: s.words,
    }));

  await saveTranscript(id, cleaned);
  return NextResponse.json({ ok: true, count: cleaned.length });
}

function sanitize(name: string): string {
  return (name || "transcript").replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80);
}
