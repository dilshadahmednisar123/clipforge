import { NextRequest, NextResponse } from "next/server";
import { getProject } from "@/lib/db/store";
import { startAnalysisPipeline } from "@/lib/jobs/pipeline";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const project = await getProject(id);
  if (!project) {
    return NextResponse.json({ error: "Project not found" }, { status: 404 });
  }

  let body: {
    language?: string;
    minClipDuration?: number;
    maxClipDuration?: number;
    targetClipCount?: number;
  } = {};
  try {
    body = await req.json();
  } catch {
    /* empty body ok */
  }

  try {
    const job = await startAnalysisPipeline(id, body);
    return NextResponse.json({ job });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to start analysis";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
