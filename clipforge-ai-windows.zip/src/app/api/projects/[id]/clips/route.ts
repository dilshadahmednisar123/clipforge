import { NextRequest, NextResponse } from "next/server";
import { getClips, saveClips, updateClip, getProject } from "@/lib/db/store";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const clips = await getClips(id);
  return NextResponse.json({ clips: clips || [] });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id: projectId } = await params;
  const project = await getProject(projectId);
  if (!project) {
    return NextResponse.json({ error: "Project not found" }, { status: 404 });
  }

  const body = await req.json();
  const { clipId, ...patch } = body;
  if (!clipId) {
    return NextResponse.json({ error: "clipId required" }, { status: 400 });
  }

  const updated = await updateClip(projectId, clipId, patch);
  if (!updated) {
    return NextResponse.json({ error: "Clip not found" }, { status: 404 });
  }
  return NextResponse.json({ clip: updated });
}

/** Bulk replace selection state */
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id: projectId } = await params;
  const body = await req.json();
  const clips = body.clips;
  if (!Array.isArray(clips)) {
    return NextResponse.json({ error: "clips array required" }, { status: 400 });
  }
  await saveClips(projectId, clips);
  return NextResponse.json({ ok: true, count: clips.length });
}
