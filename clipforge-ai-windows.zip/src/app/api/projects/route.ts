import { NextRequest, NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { listProjects, createProject } from "@/lib/db/store";
import { probeMedia } from "@/lib/media/ffprobe";
import {
  sanitizeUploadName,
  isAllowedVideoName,
  resolveUnderRoot,
} from "@/lib/security/paths";
import { dataRoot, isVercel, VERCEL_LIMITATIONS_MESSAGE } from "@/lib/platform";
import { checkFFmpeg } from "@/lib/media/ffprobe";

const MAX_SIZE = 100 * 1024 * 1024;

export async function GET() {
  const projects = await listProjects();
  return NextResponse.json({ projects });
}

export async function POST(req: NextRequest) {
  try {
    const ff = await checkFFmpeg();
    if (!ff.ffprobe) {
      return NextResponse.json(
        {
          error: isVercel()
            ? VERCEL_LIMITATIONS_MESSAGE
            : "FFprobe not found. Install FFmpeg on this host.",
        },
        { status: 503 }
      );
    }

    const UPLOAD_DIR = path.join(dataRoot(), "storage", "uploads");
    await mkdir(UPLOAD_DIR, { recursive: true });
    const form = await req.formData();
    const file = form.get("file");
    const name = (form.get("name") as string) || "Untitled Project";

    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        { error: `File too large (max ${MAX_SIZE / 1024 / 1024} MB)` },
        { status: 400 }
      );
    }

    if (!isAllowedVideoName(file.name) && !file.type.startsWith("video/")) {
      return NextResponse.json(
        { error: "Unsupported file type — use MP4, MOV, MKV, WebM, or AVI" },
        { status: 400 }
      );
    }

    const safeName = sanitizeUploadName(file.name);
    const id = randomUUID().slice(0, 8);
    const dest = resolveUnderRoot(UPLOAD_DIR, `${id}_${safeName}`);
    if (!dest) {
      return NextResponse.json({ error: "Invalid path" }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(dest, buffer);

    const metadata = await probeMedia(dest);

    if (!metadata.hasVideo) {
      return NextResponse.json(
        { error: "No video stream found" },
        { status: 400 }
      );
    }

    const project = await createProject({
      name: name.trim() || safeName,
      sourcePath: dest,
      sourceFilename: file.name,
      metadata,
    });

    return NextResponse.json({ project });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Create failed";
    console.error("[projects POST]", message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
