import { NextResponse } from "next/server";
import { checkWorkerHealth } from "@/lib/jobs/worker-client";

export async function GET() {
  const health = await checkWorkerHealth(2500);
  if (!health) {
    return NextResponse.json({
      reachable: false,
      message: "Worker not reachable at http://127.0.0.1:8765",
    });
  }
  return NextResponse.json({ reachable: true, ...health });
}
