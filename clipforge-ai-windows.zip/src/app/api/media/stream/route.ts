import { NextRequest, NextResponse } from "next/server";
import { createReadStream, statSync } from "fs";
import { promises as fs } from "fs";
import path from "path";
import { getProject } from "@/lib/db/store";
import { Readable } from "stream";

const UPLOAD_DIR = path.join(process.cwd(), "storage", "uploads");

/**
 * Stream a project's source video with HTTP Range support for seeking.
 * Only files under storage/uploads that match the project's sourcePath.
 */
export async function GET(req: NextRequest) {
  const projectId = req.nextUrl.searchParams.get("projectId");
  if (!projectId) {
    return NextResponse.json({ error: "projectId required" }, { status: 400 });
  }

  const project = await getProject(projectId);
  if (!project?.sourcePath) {
    return NextResponse.json({ error: "Project or source not found" }, { status: 404 });
  }

  const resolved = path.resolve(project.sourcePath);
  const uploadRoot = path.resolve(UPLOAD_DIR);
  if (
    resolved !== uploadRoot &&
    !resolved.startsWith(uploadRoot + path.sep)
  ) {
    return NextResponse.json({ error: "Invalid source path" }, { status: 403 });
  }

  try {
    await fs.access(resolved);
  } catch {
    return NextResponse.json({ error: "Source file missing" }, { status: 404 });
  }

  const stat = statSync(resolved);
  const fileSize = stat.size;
  const range = req.headers.get("range");

  const contentType = guessType(resolved);

  if (range) {
    const m = /bytes=(\d+)-(\d*)/.exec(range);
    if (!m) {
      return NextResponse.json({ error: "Invalid range" }, { status: 416 });
    }
    const start = parseInt(m[1], 10);
    const end = m[2] ? parseInt(m[2], 10) : Math.min(start + 1024 * 1024 - 1, fileSize - 1);
    if (start >= fileSize || end >= fileSize || start > end) {
      return new NextResponse(null, {
        status: 416,
        headers: { "Content-Range": `bytes */${fileSize}` },
      });
    }
    const chunkSize = end - start + 1;
    const nodeStream = createReadStream(resolved, { start, end });
    const webStream = Readable.toWeb(nodeStream) as ReadableStream;

    return new NextResponse(webStream, {
      status: 206,
      headers: {
        "Content-Range": `bytes ${start}-${end}/${fileSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": String(chunkSize),
        "Content-Type": contentType,
        "Cache-Control": "private, max-age=3600",
      },
    });
  }

  const nodeStream = createReadStream(resolved);
  const webStream = Readable.toWeb(nodeStream) as ReadableStream;
  return new NextResponse(webStream, {
    headers: {
      "Content-Length": String(fileSize),
      "Content-Type": contentType,
      "Accept-Ranges": "bytes",
      "Cache-Control": "private, max-age=3600",
    },
  });
}

function guessType(filePath: string): string {
  const ext = path.extname(filePath).toLowerCase();
  const map: Record<string, string> = {
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".mov": "video/quicktime",
    ".mkv": "video/x-matroska",
    ".avi": "video/x-msvideo",
    ".m4v": "video/mp4",
  };
  return map[ext] || "application/octet-stream";
}
