import { NextRequest, NextResponse } from "next/server";
import { writeFile, mkdir, unlink } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { probeMedia, checkFFmpeg } from "@/lib/media/ffprobe";
import { dataRoot, isVercel, VERCEL_LIMITATIONS_MESSAGE } from "@/lib/platform";

const MAX_SIZE = 500 * 1024 * 1024; // 500 MB

export async function POST(req: NextRequest) {
  let tempPath: string | null = null;

  try {
    const ff = await checkFFmpeg();
    if (!ff.ffprobe) {
      return NextResponse.json(
        {
          ok: false,
          error: isVercel()
            ? VERCEL_LIMITATIONS_MESSAGE
            : "FFprobe not found on this host. Install FFmpeg.",
        },
        { status: 503 }
      );
    }

    const UPLOAD_DIR = path.join(dataRoot(), "storage", "temp");
    await mkdir(UPLOAD_DIR, { recursive: true });

    const form = await req.formData();
    const file = form.get("file");

    if (!file || !(file instanceof File)) {
      return NextResponse.json(
        { ok: false, error: "No file provided" },
        { status: 400 }
      );
    }

    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        {
          ok: false,
          error: `File too large (max ${MAX_SIZE / 1024 / 1024} MB)`,
        },
        { status: 400 }
      );
    }

    // Sanitize filename
    const safeName = file.name
      .replace(/[^a-zA-Z0-9._-]/g, "_")
      .slice(0, 120);
    const id = randomUUID().slice(0, 8);
    tempPath = path.join(UPLOAD_DIR, `${id}_${safeName}`);

    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(tempPath, buffer);

    const metadata = await probeMedia(tempPath);

    if (!metadata.hasVideo) {
      return NextResponse.json(
        { ok: false, error: "No video stream found in file" },
        { status: 400 }
      );
    }

    if (metadata.duration <= 0) {
      return NextResponse.json(
        { ok: false, error: "Could not determine media duration" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      ok: true,
      metadata,
      tempId: id,
      // Note: in production we would move to permanent storage on project create
    });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : "Unexpected validation error";
    console.error("[validate]", message);
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  } finally {
    // Clean temp file after probe (project create will re-upload or move)
    if (tempPath) {
      try {
        await unlink(tempPath);
      } catch {
        /* ignore */
      }
    }
  }
}
