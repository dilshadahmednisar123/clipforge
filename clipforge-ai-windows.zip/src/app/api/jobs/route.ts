import { NextRequest, NextResponse } from "next/server";
import { listJobs, getJob } from "@/lib/db/store";

export async function GET(req: NextRequest) {
  const projectId = req.nextUrl.searchParams.get("projectId") || undefined;
  const jobId = req.nextUrl.searchParams.get("id");

  if (jobId) {
    const job = await getJob(jobId);
    if (!job) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ job });
  }

  const jobs = await listJobs(projectId);
  return NextResponse.json({ jobs });
}
