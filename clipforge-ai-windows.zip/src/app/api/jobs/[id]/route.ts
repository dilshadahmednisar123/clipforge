import { NextRequest, NextResponse } from "next/server";
import { getJob, setJobStatus, createJob, getClips } from "@/lib/db/store";
import {
  cancelJob,
  enqueueJob,
  runExportJob,
  enqueueAnalysis,
} from "@/lib/queue/job-queue";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const job = await getJob(id);
  if (!job) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json({ job });
}

/**
 * Actions: { action: "cancel" | "retry" }
 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const job = await getJob(id);
  if (!job) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: { action?: string } = {};
  try {
    body = await req.json();
  } catch {
    /* empty */
  }
  const action = body.action || "cancel";

  if (action === "cancel") {
    const ok = cancelJob(id);
    if (
      job.status !== "COMPLETED" &&
      job.status !== "FAILED" &&
      job.status !== "CANCELLED"
    ) {
      await setJobStatus(id, "CANCELLED", {
        message: "Cancelled by user",
        finishedAt: new Date().toISOString(),
      });
    }
    return NextResponse.json({ ok: true, cancelled: ok || true });
  }

  if (action === "retry") {
    if (job.type === "analyze") {
      const newJob = await enqueueAnalysis(job.projectId);
      return NextResponse.json({ ok: true, job: newJob });
    }

    if (job.type === "export") {
      // Re-export first selected clip of the project (or message if none)
      const clips = (await getClips(job.projectId)) || [];
      const clip =
        clips.find((c) => c.selected) ||
        clips.find((c) => c.exportPath) ||
        clips[0];
      if (!clip) {
        return NextResponse.json(
          { error: "No clips available to retry export" },
          { status: 400 }
        );
      }
      const newJob = await createJob({
        projectId: job.projectId,
        type: "export",
      });
      enqueueJob(newJob.id, () =>
        runExportJob(newJob.id, {
          projectId: job.projectId,
          clipId: clip.id,
        })
      );
      return NextResponse.json({ ok: true, job: newJob });
    }

    return NextResponse.json(
      { error: `Cannot retry job type: ${job.type}` },
      { status: 400 }
    );
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
