import { getJob } from "@/lib/db/store";

/**
 * Server-Sent Events stream for a single job's progress.
 * Polls the store every second until terminal state.
 */
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const encoder = new TextEncoder();
  let closed = false;

  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: unknown) => {
        if (closed) return;
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify(data)}\n\n`)
        );
      };

      try {
        for (let i = 0; i < 600 && !closed; i++) {
          const job = await getJob(id);
          if (!job) {
            send({ error: "not_found" });
            break;
          }
          send({
            id: job.id,
            status: job.status,
            progress: job.progress,
            message: job.message,
            error: job.error,
            stage: job.stage,
          });
          if (
            job.status === "COMPLETED" ||
            job.status === "FAILED" ||
            job.status === "CANCELLED"
          ) {
            break;
          }
          await new Promise((r) => setTimeout(r, 1000));
        }
      } catch (err) {
        send({
          error: err instanceof Error ? err.message : "stream error",
        });
      } finally {
        closed = true;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
    cancel() {
      closed = true;
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
