import { NextResponse } from "next/server";
import { getQueueStats } from "@/lib/queue/job-queue";
import { listJobs } from "@/lib/db/store";

export async function GET() {
  const stats = getQueueStats();
  const jobs = await listJobs();
  const active = jobs.filter(
    (j) =>
      j.status !== "COMPLETED" &&
      j.status !== "FAILED" &&
      j.status !== "CANCELLED"
  );
  const recent = jobs.slice(0, 20);
  return NextResponse.json({ stats, active, recent });
}
