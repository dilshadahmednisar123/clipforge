import { NextRequest, NextResponse } from "next/server";
import { getProject, getClips, createJob } from "@/lib/db/store";
import { enqueueJob, runExportJob } from "@/lib/queue/job-queue";

/**
 * Batch export selected clips (or explicit clipIds).
 * Body: { projectId, clipIds?: string[], aspectRatio?, captionStyle?, burnCaptions? }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      projectId,
      clipIds,
      aspectRatio = "9:16",
      captionStyle = "bold-social",
      burnCaptions = true,
    } = body;

    if (!projectId) {
      return NextResponse.json({ error: "projectId required" }, { status: 400 });
    }

    const project = await getProject(projectId);
    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 });
    }

    const allClips = (await getClips(projectId)) || [];
    const targets = clipIds?.length
      ? allClips.filter((c) => clipIds.includes(c.id))
      : allClips.filter((c) => c.selected);

    if (!targets.length) {
      return NextResponse.json(
        { error: "No clips selected for export" },
        { status: 400 }
      );
    }

    const jobs = [];
    for (const clip of targets) {
      const job = await createJob({ projectId, type: "export" });
      enqueueJob(job.id, () =>
        runExportJob(job.id, {
          projectId,
          clipId: clip.id,
          aspectRatio,
          captionStyle,
          burnCaptions,
        })
      );
      jobs.push({ jobId: job.id, clipId: clip.id, title: clip.title });
    }

    return NextResponse.json({
      ok: true,
      queued: jobs.length,
      jobs,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Batch export failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
