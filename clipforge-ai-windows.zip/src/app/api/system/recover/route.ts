import { NextResponse } from "next/server";
import { recoverInterruptedJobs, getQueueStats } from "@/lib/queue/job-queue";

/**
 * Mark interrupted jobs as FAILED so the UI can offer Retry.
 * Call once on app boot or from Settings.
 */
export async function POST() {
  const recovered = await recoverInterruptedJobs();
  const stats = getQueueStats();
  return NextResponse.json({
    ok: true,
    recovered,
    stats,
  });
}

export async function GET() {
  const stats = getQueueStats();
  return NextResponse.json({ stats });
}
