import { NextResponse } from "next/server";
import { checkFFmpeg } from "@/lib/media/ffprobe";
import { isVercel, VERCEL_LIMITATIONS_MESSAGE } from "@/lib/platform";
import { checkWorkerHealth } from "@/lib/jobs/worker-client";

export async function GET() {
  const ff = await checkFFmpeg();
  const worker = await checkWorkerHealth(2000);
  const vercel = isVercel();

  return NextResponse.json({
    platform: vercel ? "vercel" : "local",
    ffmpeg: ff.ffmpeg,
    ffprobe: ff.ffprobe,
    workerReachable: Boolean(worker),
    whisper: worker?.whisper ?? false,
    fullPipeline: ff.ffmpeg && ff.ffprobe,
    message: vercel && !ff.ffprobe ? VERCEL_LIMITATIONS_MESSAGE : null,
  });
}
