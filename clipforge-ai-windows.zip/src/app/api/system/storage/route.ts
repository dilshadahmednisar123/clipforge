import { NextRequest, NextResponse } from "next/server";
import {
  getStorageReport,
  clearTempFiles,
  listLocalModels,
} from "@/lib/system/storage";

export async function GET() {
  const [report, models] = await Promise.all([
    getStorageReport(),
    listLocalModels(),
  ]);
  return NextResponse.json({ ...report, models });
}

export async function POST(req: NextRequest) {
  let body: { action?: string } = {};
  try {
    body = await req.json();
  } catch {
    /* empty */
  }

  if (body.action === "clear-temp") {
    const result = await clearTempFiles();
    return NextResponse.json({ ok: true, ...result });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
