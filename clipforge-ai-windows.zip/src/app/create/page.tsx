"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  Upload,
  FileVideo,
  AlertCircle,
  CheckCircle2,
  Loader2,
} from "lucide-react";
import { formatBytes, formatDuration } from "@/lib/utils";

interface ValidationResult {
  ok: boolean;
  metadata?: {
    duration: number;
    width: number;
    height: number;
    fps: number;
    codec: string;
    size: number;
    format: string;
    hasAudio: boolean;
  };
  error?: string;
}

export default function CreatePage() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [validating, setValidating] = useState(false);
  const [creating, setCreating] = useState(false);
  const [result, setResult] = useState<ValidationResult | null>(null);
  const [projectName, setProjectName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [targetClips, setTargetClips] = useState(5);
  const [minDur, setMinDur] = useState(15);
  const [maxDur, setMaxDur] = useState(60);
  const [language, setLanguage] = useState("auto");

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (
      f &&
      (f.type.startsWith("video/") ||
        /\.(mp4|mov|mkv|webm|avi)$/i.test(f.name))
    ) {
      setFile(f);
      setResult(null);
      setError(null);
      setProjectName(f.name.replace(/\.[^/.]+$/, ""));
    }
  }, []);

  const onFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      setResult(null);
      setError(null);
      setProjectName(f.name.replace(/\.[^/.]+$/, ""));
    }
  };

  const validate = async () => {
    if (!file) return;
    setValidating(true);
    setResult(null);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/media/validate", {
        method: "POST",
        body: form,
      });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      setResult({
        ok: false,
        error: err instanceof Error ? err.message : "Validation failed",
      });
    } finally {
      setValidating(false);
    }
  };

  const createAndAnalyze = async () => {
    if (!file) return;
    setCreating(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("name", projectName || file.name);

      const res = await fetch("/api/projects", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to create project");

      const projectId = data.project.id;

      await fetch(`/api/projects/${projectId}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          language: language === "auto" ? undefined : language,
          minClipDuration: minDur,
          maxClipDuration: maxDur,
          targetClipCount: targetClips,
        }),
      });

      router.push(`/projects/${projectId}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Create failed");
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Create Clips</h1>
        <p className="text-sm text-muted-foreground">
          Import a video. Validate with FFprobe, then run local transcription and
          highlight scoring.
        </p>
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={`relative rounded-xl border-2 border-dashed p-10 text-center transition-colors ${
          dragOver
            ? "border-violet-500 bg-violet-500/5"
            : "border-border bg-card hover:border-muted-foreground/40"
        }`}
      >
        <input
          type="file"
          accept="video/*,.mp4,.mov,.mkv,.webm,.avi"
          onChange={onFileSelect}
          className="absolute inset-0 cursor-pointer opacity-0"
        />
        <Upload className="mx-auto h-10 w-10 text-muted-foreground" />
        <p className="mt-3 text-sm font-medium">
          Drop a video here or click to browse
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          MP4, MOV, MKV, WebM. Processing stays on your machine.
        </p>
      </div>

      {file && (
        <div className="rounded-lg border border-border bg-card p-5 space-y-4">
          <div className="flex items-start gap-3">
            <FileVideo className="h-8 w-8 shrink-0 text-violet-400" />
            <div className="min-w-0 flex-1">
              <div className="truncate font-medium">{file.name}</div>
              <div className="text-sm text-muted-foreground">
                {formatBytes(file.size)} · {file.type || "unknown type"}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5">
              Project name
            </label>
            <input
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
            />
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs text-muted-foreground mb-1">
                Target clips
              </label>
              <input
                type="number"
                min={1}
                max={20}
                value={targetClips}
                onChange={(e) => setTargetClips(Number(e.target.value) || 5)}
                className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">
                Language
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm"
              >
                <option value="auto">Auto-detect</option>
                <option value="en">English</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
                <option value="de">German</option>
                <option value="pt">Portuguese</option>
                <option value="hi">Hindi</option>
                <option value="ja">Japanese</option>
                <option value="zh">Chinese</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">
                Min duration (s)
              </label>
              <input
                type="number"
                min={5}
                max={120}
                value={minDur}
                onChange={(e) => setMinDur(Number(e.target.value) || 15)}
                className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">
                Max duration (s)
              </label>
              <input
                type="number"
                min={10}
                max={180}
                value={maxDur}
                onChange={(e) => setMaxDur(Number(e.target.value) || 60)}
                className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={validate}
              disabled={validating || creating}
              className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-muted disabled:opacity-50"
            >
              {validating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Validating…
                </>
              ) : (
                "Validate only"
              )}
            </button>
            <button
              type="button"
              onClick={createAndAnalyze}
              disabled={creating || validating}
              className="inline-flex items-center gap-2 rounded-md bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-50"
            >
              {creating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Creating…
                </>
              ) : (
                "Create & Analyze"
              )}
            </button>
          </div>

          {error && (
            <div className="flex items-start gap-2 rounded-md border border-red-500/30 bg-red-500/5 p-3 text-sm text-red-400">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          {result && (
            <div
              className={`rounded-md border p-4 text-sm ${
                result.ok
                  ? "border-emerald-500/30 bg-emerald-500/5"
                  : "border-red-500/30 bg-red-500/5"
              }`}
            >
              {result.ok && result.metadata ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 font-medium text-emerald-400">
                    <CheckCircle2 className="h-4 w-4" />
                    Valid media file
                  </div>
                  <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-muted-foreground sm:grid-cols-3">
                    <div>
                      <dt className="text-xs">Duration</dt>
                      <dd className="text-foreground">
                        {formatDuration(result.metadata.duration)}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs">Resolution</dt>
                      <dd className="text-foreground">
                        {result.metadata.width}×{result.metadata.height}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs">FPS</dt>
                      <dd className="text-foreground">
                        {result.metadata.fps.toFixed(2)}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs">Codec</dt>
                      <dd className="text-foreground">
                        {result.metadata.codec}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs">Audio</dt>
                      <dd className="text-foreground">
                        {result.metadata.hasAudio ? "Yes" : "No"}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs">Format</dt>
                      <dd className="text-foreground">
                        {result.metadata.format}
                      </dd>
                    </div>
                  </dl>
                </div>
              ) : (
                <div className="flex items-start gap-2 text-red-400">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{result.error || "Validation failed"}</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
