/**
 * Analysis pipeline: VALIDATING → TRANSCRIBING → ANALYZING → SELECTING_CLIPS → COMPLETED
 */

import {
  createJob,
  updateJob,
  setJobStatus,
  updateProject,
  saveTranscript,
  saveClips,
  getProject,
} from "@/lib/db/store";
import { selectClipCandidates } from "@/lib/scoring/engine";
import {
  checkWorkerHealth,
  transcribeLocal,
  fallbackSilenceSegments,
} from "@/lib/jobs/worker-client";
import type { TranscriptSegment, Job } from "@/types";

export async function startAnalysisPipeline(
  projectId: string,
  options?: {
    language?: string;
    minClipDuration?: number;
    maxClipDuration?: number;
    targetClipCount?: number;
  }
): Promise<Job> {
  const project = await getProject(projectId);
  if (!project) throw new Error("Project not found");

  const job = await createJob({ projectId, type: "analyze" });
  // Run async — do not await the full pipeline in the request
  void runPipeline(job.id, projectId, options).catch(async (err) => {
    console.error("[pipeline]", err);
    await setJobStatus(job.id, "FAILED", {
      error: err instanceof Error ? err.message : String(err),
      progress: 0,
    });
    await updateProject(projectId, { status: "FAILED" });
  });

  return job;
}

async function runPipeline(
  jobId: string,
  projectId: string,
  options?: {
    language?: string;
    minClipDuration?: number;
    maxClipDuration?: number;
    targetClipCount?: number;
  }
) {
  const project = await getProject(projectId);
  if (!project) throw new Error("Project not found");

  const minDur = options?.minClipDuration ?? project.settings?.minClipDuration ?? 15;
  const maxDur = options?.maxClipDuration ?? project.settings?.maxClipDuration ?? 60;
  const target = options?.targetClipCount ?? project.settings?.targetClipCount ?? 5;

  // VALIDATING
  await setJobStatus(jobId, "VALIDATING", {
    progress: 5,
    message: "Checking source file…",
    startedAt: new Date().toISOString(),
  });
  await updateProject(projectId, { status: "VALIDATING" });

  // TRANSCRIBING
  await setJobStatus(jobId, "TRANSCRIBING", {
    progress: 15,
    message: "Connecting to local worker…",
  });
  await updateProject(projectId, { status: "TRANSCRIBING" });

  const health = await checkWorkerHealth();
  let segments: TranscriptSegment[] = [];

  if (health?.whisper) {
    await updateJob(jobId, {
      progress: 25,
      message: `Transcribing with Whisper ${health.whisper_size || "tiny"}…`,
    });

    const result = await transcribeLocal(project.sourcePath, {
      language: options?.language || project.settings?.language,
      wordTimestamps: true,
    });

    if (!result.ok) {
      throw new Error(result.error || "Transcription failed");
    }

    segments = result.segments.map((s) => ({
      id: s.id,
      start: s.start,
      end: s.end,
      text: s.text,
      speaker: s.speaker,
      words: s.words?.map((w) => ({
        word: w.word,
        start: w.start,
        end: w.end,
        confidence: w.confidence,
      })),
    }));
  } else {
    // Fallback — no Whisper
    const duration = project.metadata?.duration ?? 60;
    await updateJob(jobId, {
      progress: 30,
      message:
        health
          ? "Worker online but Whisper missing — using silence-based segments"
          : "Worker offline — using silence-based placeholder segments",
    });
    segments = fallbackSilenceSegments(duration).map((s) => ({
      id: s.id,
      start: s.start,
      end: s.end,
      text: s.text,
    }));
  }

  await saveTranscript(projectId, segments);
  await updateJob(jobId, {
    progress: 55,
    message: `Transcript ready (${segments.length} segments)`,
  });

  // ANALYZING + SELECTING_CLIPS
  await setJobStatus(jobId, "ANALYZING", {
    progress: 65,
    message: "Scoring highlight candidates…",
  });
  await updateProject(projectId, { status: "ANALYZING" });

  const clips = selectClipCandidates(segments, {
    minDuration: minDur,
    maxDuration: maxDur,
    targetCount: target,
  }).map((c) => ({ ...c, projectId }));

  await saveClips(projectId, clips);

  await setJobStatus(jobId, "SELECTING_CLIPS", {
    progress: 90,
    message: `Selected ${clips.length} candidates`,
  });

  // COMPLETED
  await setJobStatus(jobId, "COMPLETED", {
    progress: 100,
    message: "Analysis complete",
    finishedAt: new Date().toISOString(),
  });
  await updateProject(projectId, {
    status: "COMPLETED",
    clipCount: clips.length,
  });
}
