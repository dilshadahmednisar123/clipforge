/**
 * Client for the local ClipForge Python worker.
 */

const WORKER_URL =
  process.env.CLIPFORGE_WORKER_URL || "http://127.0.0.1:8765";

export interface WorkerHealth {
  status: string;
  ffmpeg: boolean;
  ffprobe: boolean;
  platform: string;
  whisper: boolean;
  whisper_size?: string;
  whisper_error?: string;
  version: string;
}

export interface WorkerTranscriptWord {
  word: string;
  start: number;
  end: number;
  confidence?: number;
}

export interface WorkerTranscriptSegment {
  id: string;
  start: number;
  end: number;
  text: string;
  speaker?: string;
  words?: WorkerTranscriptWord[];
}

export interface TranscribeResult {
  ok: boolean;
  segments: WorkerTranscriptSegment[];
  language?: string;
  duration?: number;
  error?: string;
}

export async function checkWorkerHealth(
  timeoutMs = 3000
): Promise<WorkerHealth | null> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    const res = await fetch(`${WORKER_URL}/health`, { signal: ctrl.signal });
    clearTimeout(t);
    if (!res.ok) return null;
    return (await res.json()) as WorkerHealth;
  } catch {
    return null;
  }
}

export async function transcribeLocal(
  filePath: string,
  options?: { language?: string; wordTimestamps?: boolean }
): Promise<TranscribeResult> {
  const form = new FormData();
  form.append("path", filePath);
  if (options?.language) form.append("language", options.language);
  form.append(
    "word_timestamps",
    String(options?.wordTimestamps !== false)
  );

  const res = await fetch(`${WORKER_URL}/transcribe`, {
    method: "POST",
    body: form,
  });

  if (!res.ok) {
    const text = await res.text();
    return { ok: false, segments: [], error: text || res.statusText };
  }

  return (await res.json()) as TranscribeResult;
}

/**
 * Fallback: generate a coarse transcript from silence detection via FFmpeg
 * when Whisper is unavailable. Produces segment placeholders, not real words.
 */
export function fallbackSilenceSegments(
  duration: number,
  interval = 8
): WorkerTranscriptSegment[] {
  const segs: WorkerTranscriptSegment[] = [];
  let t = 0;
  let i = 0;
  while (t < duration) {
    const end = Math.min(duration, t + interval);
    segs.push({
      id: `fallback-${i}`,
      start: t,
      end,
      text: `[Speech segment ${i + 1} — install faster-whisper for real transcription]`,
    });
    t = end;
    i++;
  }
  return segs;
}
