/**
 * Path safety helpers — prevent traversal and unsafe filenames.
 */

import path from "path";

const SAFE_NAME = /^[a-zA-Z0-9._-]+$/;

/**
 * Return basename only if it contains no path separators or `..`.
 */
export function safeBasename(input: string): string | null {
  if (!input || typeof input !== "string") return null;
  const base = path.basename(input);
  if (!base || base === "." || base === "..") return null;
  if (base.includes("..")) return null;
  // Reject absolute-looking or separator-containing originals
  if (input.includes("\0")) return null;
  if (/[/\\]/.test(input) && path.basename(input) !== input.replace(/\\/g, "/").split("/").pop()) {
    // Allow only pure basenames for download endpoints
    if (input !== base && input !== `./${base}`) return null;
  }
  // For download API we require exact basename match
  if (input !== base && !input.endsWith(base)) return null;
  return base;
}

/**
 * Strict basename for user-facing download query params.
 */
export function downloadBasename(input: string): string | null {
  if (!input || typeof input !== "string") return null;
  if (input.includes("\0") || input.includes("..")) return null;
  if (/[/\\]/.test(input)) return null;
  if (!SAFE_NAME.test(input)) return null;
  return input;
}

/**
 * Resolve a path and ensure it stays under `root`.
 */
export function resolveUnderRoot(root: string, ...parts: string[]): string | null {
  const rootResolved = path.resolve(root);
  const candidate = path.resolve(rootResolved, ...parts);
  if (
    candidate !== rootResolved &&
    !candidate.startsWith(rootResolved + path.sep)
  ) {
    return null;
  }
  return candidate;
}

/**
 * Sanitize an upload filename (keep extension, strip unsafe chars).
 */
export function sanitizeUploadName(name: string, maxLen = 120): string {
  const base = path.basename(name || "upload.bin");
  const cleaned = base.replace(/[^a-zA-Z0-9._-]/g, "_").replace(/_{2,}/g, "_");
  return cleaned.slice(0, maxLen) || "upload.bin";
}

/**
 * True if extension looks like a video we accept.
 */
export function isAllowedVideoName(name: string): boolean {
  return /\.(mp4|mov|mkv|webm|avi|m4v)$/i.test(name);
}
