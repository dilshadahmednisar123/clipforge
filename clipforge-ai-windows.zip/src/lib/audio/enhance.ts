/**
 * Local audio enhancement filter fragments for FFmpeg.
 * Deterministic filters only — no cloud services.
 */

export interface AudioEnhanceOptions {
  /** EBU R128 loudness normalization */
  loudnorm?: boolean;
  /** Target integrated loudness (LUFS), default -14 for social */
  targetLufs?: number;
  /** Fade in/out seconds */
  fadeIn?: number;
  fadeOut?: number;
  /** Highpass to reduce rumble (Hz), 0 = off */
  highpass?: number;
}

/**
 * Build an audio filter chain string, or empty if no processing requested.
 */
export function buildAudioFilters(
  options: AudioEnhanceOptions,
  clipDuration: number
): string {
  const parts: string[] = [];

  if (options.highpass && options.highpass > 0) {
    parts.push(`highpass=f=${Math.round(options.highpass)}`);
  }

  if (options.loudnorm) {
    const I = options.targetLufs ?? -14;
    // Single-pass loudnorm (good enough for short clips)
    parts.push(`loudnorm=I=${I}:TP=-1.5:LRA=11`);
  }

  const fadeIn = options.fadeIn ?? 0;
  const fadeOut = options.fadeOut ?? 0;
  if (fadeIn > 0) {
    parts.push(`afade=t=in:st=0:d=${fadeIn.toFixed(2)}`);
  }
  if (fadeOut > 0 && clipDuration > fadeOut) {
    const st = Math.max(0, clipDuration - fadeOut);
    parts.push(`afade=t=out:st=${st.toFixed(2)}:d=${fadeOut.toFixed(2)}`);
  }

  return parts.join(",");
}
