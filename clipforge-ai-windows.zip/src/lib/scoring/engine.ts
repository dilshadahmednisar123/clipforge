/**
 * ClipForge highlight scoring engine
 *
 * Deterministic heuristics — no LLM required.
 * Scores 0–100 with explainable dimension breakdown.
 * Designed to be replaced/augmented by local embeddings later.
 */

import { randomUUID } from "crypto";
import type { TranscriptSegment, ClipCandidate } from "@/types";

export interface ScoringWeights {
  hookPotential: number;
  narrativeCompleteness: number;
  emotionalEmphasis: number;
  standaloneContext: number;
  informationDensity: number;
  endingQuality: number;
  silencePenalty: number;
  incompleteSentencePenalty: number;
}

export const DEFAULT_WEIGHTS: ScoringWeights = {
  hookPotential: 1.4,
  narrativeCompleteness: 1.2,
  emotionalEmphasis: 1.0,
  standaloneContext: 1.1,
  informationDensity: 1.0,
  endingQuality: 0.9,
  silencePenalty: 1.3,
  incompleteSentencePenalty: 1.0,
};

export interface ScoringOptions {
  minDuration: number;
  maxDuration: number;
  targetCount: number;
  weights?: Partial<ScoringWeights>;
  /** Prefer starts near these timestamps (e.g. after long pauses) */
  preferStarts?: number[];
}

const HOOK_WORDS =
  /\b(you|your|why|how|what if|secret|mistake|never|always|stop|start|truth|shocking|insane|crazy|best|worst|only|must|need to|should|don't|won't|can't)\b/i;

const EMPHASIS_WORDS =
  /\b(amazing|incredible|unbelievable|wow|oh my|literally|actually|basically|honestly|seriously|important|critical|key|essential)\b/i;

const QUESTION_RE = /\?/;
const EXCLAIM_RE = /!/;
const SENTENCE_END = /[.!?]\s*$/;

function segmentText(segs: TranscriptSegment[]): string {
  return segs.map((s) => s.text).join(" ").trim();
}

function wordCount(text: string): number {
  return text.split(/\s+/).filter(Boolean).length;
}

function hasIncompleteEnd(text: string): boolean {
  const t = text.trim();
  if (!t) return true;
  return !SENTENCE_END.test(t) && !/[.!?]"?\s*$/.test(t);
}

function silenceRatio(
  segs: TranscriptSegment[],
  start: number,
  end: number
): number {
  if (end <= start) return 1;
  let spoken = 0;
  for (const s of segs) {
    const a = Math.max(s.start, start);
    const b = Math.min(s.end, end);
    if (b > a) spoken += b - a;
  }
  return Math.max(0, 1 - spoken / (end - start));
}

function scoreWindow(
  segs: TranscriptSegment[],
  start: number,
  end: number,
  weights: ScoringWeights
): { score: number; breakdown: Record<string, number> } {
  const inWindow = segs.filter((s) => s.end > start && s.start < end);
  const text = segmentText(inWindow);
  const duration = end - start;
  const words = wordCount(text);
  const density = duration > 0 ? words / duration : 0;

  // Hook potential — first 5s of the window
  const hookEnd = Math.min(start + 5, end);
  const hookSegs = segs.filter((s) => s.end > start && s.start < hookEnd);
  const hookText = segmentText(hookSegs);
  let hook = 40;
  if (HOOK_WORDS.test(hookText)) hook += 25;
  if (QUESTION_RE.test(hookText)) hook += 15;
  if (EXCLAIM_RE.test(hookText)) hook += 10;
  if (wordCount(hookText) >= 8) hook += 10;
  hook = Math.min(100, hook);

  // Narrative completeness — closed thought
  let narrative = 50;
  if (SENTENCE_END.test(text.trim())) narrative += 20;
  if (words >= 20 && words <= 120) narrative += 15;
  if (inWindow.length >= 2) narrative += 10;
  if (hasIncompleteEnd(text)) narrative -= 25;
  narrative = Math.max(0, Math.min(100, narrative));

  // Emotional / vocal emphasis (text proxies)
  let emotional = 40;
  if (EMPHASIS_WORDS.test(text)) emotional += 25;
  if (EXCLAIM_RE.test(text)) emotional += 15;
  if (QUESTION_RE.test(text)) emotional += 10;
  emotional = Math.min(100, emotional);

  // Standalone context — starts after a pause, ends cleanly
  let standalone = 45;
  const gapBefore =
    inWindow.length > 0
      ? Math.max(0, inWindow[0].start - (start > 0.5 ? start : 0))
      : 0;
  if (gapBefore < 1.5) standalone += 15; // starts near speech
  if (!hasIncompleteEnd(text)) standalone += 20;
  if (words >= 12) standalone += 10;
  standalone = Math.min(100, standalone);

  // Information density
  let info = 30;
  if (density >= 1.5 && density <= 4) info += 40;
  else if (density > 0.8) info += 20;
  if (words >= 15) info += 15;
  info = Math.min(100, info);

  // Ending quality
  let ending = 50;
  const lastText = inWindow.length
    ? inWindow[inWindow.length - 1].text.trim()
    : "";
  if (SENTENCE_END.test(lastText)) ending += 30;
  if (!hasIncompleteEnd(text)) ending += 15;
  ending = Math.min(100, ending);

  // Penalties
  const sil = silenceRatio(segs, start, end);
  const silencePenalty = sil > 0.35 ? sil * 100 : sil * 40;
  const incompletePenalty = hasIncompleteEnd(text) ? 35 : 0;

  const raw =
    (hook * weights.hookPotential +
      narrative * weights.narrativeCompleteness +
      emotional * weights.emotionalEmphasis +
      standalone * weights.standaloneContext +
      info * weights.informationDensity +
      ending * weights.endingQuality) /
      (weights.hookPotential +
        weights.narrativeCompleteness +
        weights.emotionalEmphasis +
        weights.standaloneContext +
        weights.informationDensity +
        weights.endingQuality) -
    silencePenalty * weights.silencePenalty * 0.15 -
    incompletePenalty * weights.incompleteSentencePenalty * 0.2;

  const score = Math.round(Math.max(0, Math.min(100, raw)));

  return {
    score,
    breakdown: {
      hookPotential: Math.round(hook),
      narrativeCompleteness: Math.round(narrative),
      emotionalEmphasis: Math.round(emotional),
      standaloneContext: Math.round(standalone),
      informationDensity: Math.round(info),
      endingQuality: Math.round(ending),
      silencePenalty: Math.round(silencePenalty),
      incompleteSentencePenalty: incompletePenalty,
    },
  };
}

/**
 * Generate candidate clips from a transcript.
 * Sliding windows over speech segments, scored, NMS-style de-duplication.
 */
export function selectClipCandidates(
  segments: TranscriptSegment[],
  options: ScoringOptions
): ClipCandidate[] {
  if (!segments.length) return [];

  const weights = { ...DEFAULT_WEIGHTS, ...options.weights };
  const { minDuration, maxDuration, targetCount } = options;

  const totalEnd = Math.max(...segments.map((s) => s.end));
  const candidates: Array<{
    start: number;
    end: number;
    score: number;
    breakdown: Record<string, number>;
    text: string;
  }> = [];

  // Build candidate windows anchored on segment starts
  for (let i = 0; i < segments.length; i++) {
    const start = Math.max(0, segments[i].start - 0.3);
    for (
      let dur = minDuration;
      dur <= maxDuration;
      dur += Math.max(5, (maxDuration - minDuration) / 4)
    ) {
      const end = Math.min(totalEnd, start + dur);
      if (end - start < minDuration * 0.9) continue;

      const { score, breakdown } = scoreWindow(segments, start, end, weights);
      const text = segmentText(
        segments.filter((s) => s.end > start && s.start < end)
      );
      if (wordCount(text) < 8) continue;

      candidates.push({ start, end, score, breakdown, text });
    }
  }

  // Also try mid-segment anchors for variety
  for (let i = 0; i < segments.length; i += 2) {
    const mid = (segments[i].start + segments[i].end) / 2;
    const start = Math.max(0, mid - minDuration / 2);
    const end = Math.min(totalEnd, start + (minDuration + maxDuration) / 2);
    if (end - start < minDuration) continue;
    const { score, breakdown } = scoreWindow(segments, start, end, weights);
    const text = segmentText(
      segments.filter((s) => s.end > start && s.start < end)
    );
    if (wordCount(text) < 8) continue;
    candidates.push({ start, end, score, breakdown, text });
  }

  // Sort by score descending
  candidates.sort((a, b) => b.score - a.score);

  // Non-maximum suppression: reject heavy overlap with higher-scored picks
  const selected: typeof candidates = [];
  const overlapThreshold = 0.45;

  for (const c of candidates) {
    if (selected.length >= targetCount * 2) break; // gather extras then trim
    const overlaps = selected.some((s) => {
      const overlap =
        Math.max(0, Math.min(c.end, s.end) - Math.max(c.start, s.start)) /
        Math.min(c.end - c.start, s.end - s.start);
      return overlap > overlapThreshold;
    });
    if (!overlaps) selected.push(c);
  }

  // Take top targetCount
  const final = selected.slice(0, targetCount);

  return final.map((c, idx) => {
    // Short title from first ~8 words
    const words = c.text.split(/\s+/).slice(0, 8).join(" ");
    const title =
      words.length > 50 ? words.slice(0, 47) + "…" : words || `Clip ${idx + 1}`;

    return {
      id: randomUUID(),
      projectId: "", // filled by caller
      start: Math.round(c.start * 100) / 100,
      end: Math.round(c.end * 100) / 100,
      score: c.score,
      title,
      summary: c.text.slice(0, 200) + (c.text.length > 200 ? "…" : ""),
      scoreBreakdown: c.breakdown,
      selected: idx < Math.min(3, targetCount), // auto-select top few
    } satisfies ClipCandidate;
  });
}

/**
 * Re-score a manually adjusted window (for editor trim).
 */
export function scoreClipRange(
  segments: TranscriptSegment[],
  start: number,
  end: number,
  weights?: Partial<ScoringWeights>
): { score: number; breakdown: Record<string, number> } {
  return scoreWindow(segments, start, end, {
    ...DEFAULT_WEIGHTS,
    ...weights,
  });
}
