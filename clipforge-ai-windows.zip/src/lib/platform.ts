/**
 * Runtime platform detection for graceful degradation on Vercel.
 */

export function isVercel(): boolean {
  return process.env.VERCEL === "1" || process.env.VERCEL === "true";
}

export function isServerless(): boolean {
  return isVercel() || Boolean(process.env.AWS_LAMBDA_FUNCTION_NAME);
}

/**
 * Writable data root. On Vercel, only /tmp is writable (ephemeral).
 */
export function dataRoot(): string {
  if (isVercel()) {
    return "/tmp/clipforge";
  }
  return process.cwd();
}

export const VERCEL_LIMITATIONS_MESSAGE =
  "This ClipForge feature needs a host with FFmpeg and persistent disk " +
  "(local machine, Docker, or a VPS). Vercel serverless cannot run the " +
  "full video pipeline. See docs/FREE-DEPLOY.md or docs/VERCEL.md.";
