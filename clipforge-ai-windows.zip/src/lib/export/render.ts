/**
 * Clip render pipeline using FFmpeg.
 * Trim → reframe → optional ASS burn-in → H.264/AAC MP4.
 */

import { execFile } from "child_process";
import { promisify } from "util";
import { promises as fs } from "fs";
import path from "path";
import { randomUUID } from "crypto";
import {
  generateASS,
  generateSRT,
  getStyle,
  sliceTranscriptForClip,
  type CaptionStyleId,
} from "@/lib/captions/generator";
import {
  computeCrop,
  buildReframeFilter,
  type AspectRatio,
} from "@/lib/reframe/crop";
import {
  buildAudioFilters,
  type AudioEnhanceOptions,
} from "@/lib/audio/enhance";
import type { TranscriptSegment } from "@/types";

const execFileAsync = promisify(execFile);

const EXPORT_DIR = path.join(process.cwd(), "storage", "exports");
const TEMP_DIR = path.join(process.cwd(), "storage", "temp");

export interface RenderOptions {
  sourcePath: string;
  start: number;
  end: number;
  aspectRatio: AspectRatio;
  srcWidth: number;
  srcHeight: number;
  captionStyle?: CaptionStyleId | string;
  burnCaptions?: boolean;
  segments?: TranscriptSegment[];
  focalX?: number;
  focalY?: number;
  outputName?: string;
  crf?: number; // 18–28, lower = higher quality
  fps?: number;
  audio?: AudioEnhanceOptions;
}

export interface RenderResult {
  ok: boolean;
  outputPath?: string;
  filename?: string;
  duration?: number;
  width?: number;
  height?: number;
  size?: number;
  srtPath?: string;
  error?: string;
  filterNote?: string;
}

async function ensureDirs() {
  await fs.mkdir(EXPORT_DIR, { recursive: true });
  await fs.mkdir(TEMP_DIR, { recursive: true });
}

/**
 * Verify output file exists and has a video stream with expected duration ±2s.
 */
async function verifyOutput(
  filePath: string,
  expectedDuration: number
): Promise<{ ok: boolean; duration?: number; width?: number; height?: number; size?: number; error?: string }> {
  try {
    const stat = await fs.stat(filePath);
    if (stat.size < 1000) {
      return { ok: false, error: "Output file too small" };
    }
    const { stdout } = await execFileAsync(
      "ffprobe",
      [
        "-v",
        "quiet",
        "-print_format",
        "json",
        "-show_format",
        "-show_streams",
        filePath,
      ],
      { timeout: 30000 }
    );
    const data = JSON.parse(stdout);
    const video = (data.streams || []).find(
      (s: { codec_type: string }) => s.codec_type === "video"
    );
    if (!video) return { ok: false, error: "No video stream in output" };
    const duration = Number(data.format?.duration) || 0;
    if (Math.abs(duration - expectedDuration) > 2.5 && expectedDuration > 3) {
      return {
        ok: false,
        error: `Duration mismatch: got ${duration.toFixed(1)}s, expected ~${expectedDuration.toFixed(1)}s`,
      };
    }
    return {
      ok: true,
      duration,
      width: video.width,
      height: video.height,
      size: stat.size,
    };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : "Verify failed",
    };
  }
}

export async function renderClip(opts: RenderOptions): Promise<RenderResult> {
  await ensureDirs();

  const duration = opts.end - opts.start;
  if (duration <= 0.5) {
    return { ok: false, error: "Clip duration too short" };
  }

  try {
    await fs.access(opts.sourcePath);
  } catch {
    return { ok: false, error: `Source not found: ${opts.sourcePath}` };
  }

  const crop = computeCrop(opts.srcWidth, opts.srcHeight, opts.aspectRatio, {
    focalX: opts.focalX,
    focalY: opts.focalY,
  });

  const id = randomUUID().slice(0, 8);
  const baseName =
    opts.outputName?.replace(/[^a-zA-Z0-9._-]/g, "_") || `clip_${id}`;
  const outPath = path.join(EXPORT_DIR, `${baseName}.mp4`);
  const assPath = path.join(TEMP_DIR, `${id}.ass`);
  const srtPath = path.join(EXPORT_DIR, `${baseName}.srt`);

  let videoFilter = buildReframeFilter(crop);
  let assWritten = false;

  // Captions
  if (opts.burnCaptions && opts.segments?.length) {
    const sliced = sliceTranscriptForClip(
      opts.segments,
      opts.start,
      opts.end
    );
    if (sliced.length) {
      const style = getStyle(opts.captionStyle || "bold-social");
      const ass = generateASS(sliced, style, crop.outW, crop.outH);
      await fs.writeFile(assPath, ass, "utf-8");
      assWritten = true;

      // Also write SRT sidecar
      const srt = generateSRT(sliced, style);
      await fs.writeFile(srtPath, srt, "utf-8");

      // Escape path for FFmpeg subtitles filter (Windows + special chars)
      const assEscaped = assPath
        .replace(/\\/g, "/")
        .replace(/:/g, "\\:")
        .replace(/'/g, "\\'");
      videoFilter += `,subtitles='${assEscaped}'`;
    }
  } else if (opts.segments?.length) {
    // Sidecar only
    const sliced = sliceTranscriptForClip(
      opts.segments,
      opts.start,
      opts.end
    );
    if (sliced.length) {
      const style = getStyle(opts.captionStyle || "bold-social");
      await fs.writeFile(srtPath, generateSRT(sliced, style), "utf-8");
    }
  }

  const crf = opts.crf ?? 20;
  const fps = opts.fps;

  const args = [
    "-y",
    "-ss",
    String(opts.start),
    "-i",
    opts.sourcePath,
    "-t",
    String(duration),
    "-vf",
    videoFilter,
    "-c:v",
    "libx264",
    "-preset",
    "fast",
    "-crf",
    String(crf),
    "-c:a",
    "aac",
    "-b:a",
    "128k",
    "-movflags",
    "+faststart",
    "-pix_fmt",
    "yuv420p",
  ];

  if (fps) {
    args.push("-r", String(fps));
  }

  const audioFilter = buildAudioFilters(opts.audio || {}, duration);
  if (audioFilter) {
    args.push("-af", audioFilter);
  }

  args.push(outPath);

  try {
    await execFileAsync("ffmpeg", args, {
      timeout: 600_000,
      maxBuffer: 10 * 1024 * 1024,
    });
  } catch (err) {
    const msg =
      err instanceof Error
        ? // child_process error often has stderr
          ((err as { stderr?: Buffer }).stderr?.toString() || err.message)
        : String(err);
    return {
      ok: false,
      error: `FFmpeg failed: ${msg.slice(0, 400)}`,
      filterNote: crop.note,
    };
  } finally {
    if (assWritten) {
      try {
        await fs.unlink(assPath);
      } catch {
        /* ignore */
      }
    }
  }

  const verify = await verifyOutput(outPath, duration);
  if (!verify.ok) {
    return {
      ok: false,
      error: verify.error || "Output verification failed",
      filterNote: crop.note,
    };
  }

  return {
    ok: true,
    outputPath: outPath,
    filename: path.basename(outPath),
    duration: verify.duration,
    width: verify.width,
    height: verify.height,
    size: verify.size,
    srtPath: await fs
      .access(srtPath)
      .then(() => srtPath)
      .catch(() => undefined),
    filterNote: crop.note,
  };
}
