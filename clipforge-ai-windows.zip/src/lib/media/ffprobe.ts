import { execFile } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs/promises";

const execFileAsync = promisify(execFile);

export interface ProbeResult {
  duration: number;
  width: number;
  height: number;
  fps: number;
  codec: string;
  audioCodec?: string;
  bitrate?: number;
  size: number;
  format: string;
  hasAudio: boolean;
  hasVideo: boolean;
}

/**
 * Run ffprobe on a local file path and return normalized metadata.
 * Uses argument array — never shell interpolation.
 */
export async function probeMedia(filePath: string): Promise<ProbeResult> {
  // Security: resolve and ensure path is under allowed storage roots later
  const abs = path.resolve(filePath);

  try {
    await fs.access(abs);
  } catch {
    throw new Error(`File not found: ${abs}`);
  }

  const { stdout } = await execFileAsync(
    "ffprobe",
    [
      "-v",
      "quiet",
      "-print_format",
      "json",
      "-show_format",
      "-show_streams",
      abs,
    ],
    { timeout: 60_000, maxBuffer: 5 * 1024 * 1024 }
  );

  const data = JSON.parse(stdout);
  const format = data.format || {};
  const streams = data.streams || [];

  const video = streams.find((s: { codec_type: string }) => s.codec_type === "video");
  const audio = streams.find((s: { codec_type: string }) => s.codec_type === "audio");

  let fps = 0;
  if (video?.r_frame_rate) {
    const [num, den] = video.r_frame_rate.split("/").map(Number);
    if (den) fps = num / den;
  } else if (video?.avg_frame_rate) {
    const [num, den] = video.avg_frame_rate.split("/").map(Number);
    if (den) fps = num / den;
  }

  const size = Number(format.size) || 0;
  const duration = Number(format.duration) || 0;

  return {
    duration,
    width: video?.width || 0,
    height: video?.height || 0,
    fps,
    codec: video?.codec_name || "unknown",
    audioCodec: audio?.codec_name,
    bitrate: format.bit_rate ? Number(format.bit_rate) : undefined,
    size,
    format: format.format_name?.split(",")[0] || "unknown",
    hasAudio: Boolean(audio),
    hasVideo: Boolean(video),
  };
}

/**
 * Check whether ffmpeg and ffprobe are available on PATH.
 */
export async function checkFFmpeg(): Promise<{
  ffmpeg: boolean;
  ffprobe: boolean;
  version?: string;
}> {
  let ffmpeg = false;
  let ffprobe = false;
  let version: string | undefined;

  try {
    const { stdout } = await execFileAsync("ffmpeg", ["-version"], {
      timeout: 5000,
    });
    ffmpeg = true;
    version = stdout.split("\n")[0];
  } catch {
    /* not found */
  }

  try {
    await execFileAsync("ffprobe", ["-version"], { timeout: 5000 });
    ffprobe = true;
  } catch {
    /* not found */
  }

  return { ffmpeg, ffprobe, version };
}
