/**
 * In-process job queue with bounded concurrency, cancellation, and recovery.
 * Jobs are persisted via the file store; this module only schedules work.
 */

import {
  listJobs,
  getJob,
  setJobStatus,
  updateJob,
  getProject,
  getClips,
  getTranscript,
  updateClip,
  updateProject,
} from "@/lib/db/store";
import { startAnalysisPipeline } from "@/lib/jobs/pipeline";
import { renderClip } from "@/lib/export/render";
import type { AspectRatio } from "@/lib/reframe/crop";
import type { Job, JobStatus } from "@/types";

const MAX_CONCURRENT = Number(process.env.CLIPFORGE_MAX_JOBS || 1);
const cancelled = new Set<string>();
const running = new Map<string, AbortController>();

let activeCount = 0;
const waitQueue: Array<{
  jobId: string;
  fn: () => Promise<void>;
}> = [];

function isTerminal(status: JobStatus): boolean {
  return status === "COMPLETED" || status === "FAILED" || status === "CANCELLED";
}

async function pump() {
  while (activeCount < MAX_CONCURRENT && waitQueue.length > 0) {
    const next = waitQueue.shift();
    if (!next) break;
    if (cancelled.has(next.jobId)) {
      await setJobStatus(next.jobId, "CANCELLED", {
        progress: 0,
        message: "Cancelled before start",
        finishedAt: new Date().toISOString(),
      });
      cancelled.delete(next.jobId);
      continue;
    }
    activeCount++;
    const ctrl = new AbortController();
    running.set(next.jobId, ctrl);
    next
      .fn()
      .catch(async (err) => {
        if (cancelled.has(next.jobId) || ctrl.signal.aborted) {
          await setJobStatus(next.jobId, "CANCELLED", {
            message: "Cancelled",
            finishedAt: new Date().toISOString(),
          });
        } else {
          await setJobStatus(next.jobId, "FAILED", {
            error: err instanceof Error ? err.message : String(err),
            finishedAt: new Date().toISOString(),
          });
        }
      })
      .finally(() => {
        activeCount--;
        running.delete(next.jobId);
        cancelled.delete(next.jobId);
        void pump();
      });
  }
}

export function enqueueJob(jobId: string, fn: () => Promise<void>) {
  waitQueue.push({ jobId, fn });
  void pump();
}

export function cancelJob(jobId: string): boolean {
  cancelled.add(jobId);
  const ctrl = running.get(jobId);
  if (ctrl) {
    ctrl.abort();
    return true;
  }
  // If still queued, pump will mark CANCELLED
  const idx = waitQueue.findIndex((w) => w.jobId === jobId);
  if (idx >= 0) {
    waitQueue.splice(idx, 1);
    void setJobStatus(jobId, "CANCELLED", {
      message: "Cancelled while queued",
      finishedAt: new Date().toISOString(),
    });
    return true;
  }
  return cancelled.has(jobId);
}

export function isCancelled(jobId: string): boolean {
  return cancelled.has(jobId) || running.get(jobId)?.signal.aborted === true;
}

/**
 * On process start: mark any non-terminal jobs as interrupted so the UI
 * can offer retry. Does not auto-restart heavy work without user action.
 */
export async function recoverInterruptedJobs(): Promise<number> {
  const jobs = await listJobs();
  let count = 0;
  for (const job of jobs) {
    if (!isTerminal(job.status)) {
      await setJobStatus(job.id, "FAILED", {
        error: "Interrupted by process restart. Use Retry to resume.",
        message: "Interrupted",
        finishedAt: new Date().toISOString(),
      });
      const project = await getProject(job.projectId);
      if (project && !isTerminal(project.status as JobStatus)) {
        await updateProject(job.projectId, { status: "FAILED" });
      }
      count++;
    }
  }
  return count;
}

// ── Export job runner (used by single + batch) ────────────────────────────

export async function runExportJob(
  jobId: string,
  opts: {
    projectId: string;
    clipId: string;
    aspectRatio?: string;
    captionStyle?: string;
    burnCaptions?: boolean;
    focalX?: number;
    focalY?: number;
    start?: number;
    end?: number;
  }
): Promise<void> {
  if (isCancelled(jobId)) {
    await setJobStatus(jobId, "CANCELLED", {
      finishedAt: new Date().toISOString(),
    });
    return;
  }

  await setJobStatus(jobId, "RENDERING", {
    progress: 10,
    message: "Loading project…",
    startedAt: new Date().toISOString(),
  });

  const project = await getProject(opts.projectId);
  if (!project) throw new Error("Project not found");

  const clips = (await getClips(opts.projectId)) || [];
  const clip = clips.find((c) => c.id === opts.clipId);
  if (!clip) throw new Error("Clip not found");

  if (isCancelled(jobId)) {
    await setJobStatus(jobId, "CANCELLED", {
      finishedAt: new Date().toISOString(),
    });
    return;
  }

  await updateJob(jobId, { progress: 30, message: "Rendering with FFmpeg…" });

  const start = opts.start ?? clip.start;
  const end = opts.end ?? clip.end;
  const segments = (await getTranscript(opts.projectId)) || [];
  const meta = project.metadata;

  const result = await renderClip({
    sourcePath: project.sourcePath,
    start,
    end,
    aspectRatio: (opts.aspectRatio as AspectRatio) || "9:16",
    srcWidth: meta?.width || 1920,
    srcHeight: meta?.height || 1080,
    captionStyle: opts.captionStyle || "bold-social",
    burnCaptions: opts.burnCaptions !== false,
    segments,
    focalX: opts.focalX,
    focalY: opts.focalY,
    outputName: `${project.name.slice(0, 40)}_${opts.clipId.slice(0, 6)}`,
  });

  if (isCancelled(jobId)) {
    await setJobStatus(jobId, "CANCELLED", {
      finishedAt: new Date().toISOString(),
    });
    return;
  }

  if (!result.ok) {
    throw new Error(result.error || "Render failed");
  }

  await updateClip(opts.projectId, opts.clipId, {
    exportPath: result.outputPath,
    aspectRatio: opts.aspectRatio || "9:16",
    start,
    end,
  });

  await setJobStatus(jobId, "VERIFYING", {
    progress: 90,
    message: "Verified output",
  });

  await setJobStatus(jobId, "COMPLETED", {
    progress: 100,
    message: result.filename || "Export complete",
    finishedAt: new Date().toISOString(),
  });

  await updateProject(opts.projectId, {
    exportCount: (project.exportCount || 0) + 1,
  });
}

export function getQueueStats() {
  return {
    maxConcurrent: MAX_CONCURRENT,
    active: activeCount,
    queued: waitQueue.length,
    runningJobIds: Array.from(running.keys()),
  };
}

// Re-export analysis enqueue helper
export async function enqueueAnalysis(
  projectId: string,
  options?: {
    language?: string;
    minClipDuration?: number;
    maxClipDuration?: number;
    targetClipCount?: number;
  }
): Promise<Job> {
  // startAnalysisPipeline already creates a job and runs async;
  // keep using it for analysis path.
  return startAnalysisPipeline(projectId, options);
}
