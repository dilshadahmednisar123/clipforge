/**
 * Vertical / square reframing helpers.
 *
 * Without vision models we use center-crop with optional focal point
 * and blurred-background fill. When face detection is available later,
 * the same CropWindow shape is produced by the tracker.
 */

export type AspectRatio = "9:16" | "1:1" | "4:5" | "16:9";

export interface CropWindow {
  /** Source crop region in pixels */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Output dimensions */
  outW: number;
  outH: number;
  /** Strategy used */
  mode: "center" | "focal" | "blur-fill" | "tracked";
  note?: string;
}

export const ASPECT_PRESETS: Record<
  AspectRatio,
  { w: number; h: number; label: string }
> = {
  "9:16": { w: 1080, h: 1920, label: "Vertical (TikTok / Reels / Shorts)" },
  "1:1": { w: 1080, h: 1080, label: "Square" },
  "4:5": { w: 1080, h: 1350, label: "Portrait 4:5" },
  "16:9": { w: 1920, h: 1080, label: "Landscape" },
};

/**
 * Compute a crop window for the given source size and target aspect.
 * focalX/focalY are normalized 0–1 (default center).
 */
export function computeCrop(
  srcW: number,
  srcH: number,
  aspect: AspectRatio,
  options?: {
    focalX?: number; // 0–1
    focalY?: number;
    preferBlurFill?: boolean;
  }
): CropWindow {
  const preset = ASPECT_PRESETS[aspect];
  const targetRatio = preset.w / preset.h;
  const srcRatio = srcW / srcH;

  const focalX = options?.focalX ?? 0.5;
  const focalY = options?.focalY ?? 0.5;

  // If source is already close to target, scale to fit
  if (Math.abs(srcRatio - targetRatio) < 0.02) {
    return {
      x: 0,
      y: 0,
      w: srcW,
      h: srcH,
      outW: preset.w,
      outH: preset.h,
      mode: "center",
      note: "Source matches target aspect",
    };
  }

  let cropW: number;
  let cropH: number;

  if (srcRatio > targetRatio) {
    // Source wider than target → crop sides
    cropH = srcH;
    cropW = Math.round(srcH * targetRatio);
  } else {
    // Source taller → crop top/bottom
    cropW = srcW;
    cropH = Math.round(srcW / targetRatio);
  }

  // Anchor crop around focal point
  let x = Math.round(focalX * srcW - cropW / 2);
  let y = Math.round(focalY * srcH - cropH / 2);
  x = Math.max(0, Math.min(srcW - cropW, x));
  y = Math.max(0, Math.min(srcH - cropH, y));

  const mode =
    options?.preferBlurFill && (srcRatio > targetRatio * 1.15 || srcRatio < targetRatio / 1.15)
      ? "blur-fill"
      : Math.abs(focalX - 0.5) > 0.05 || Math.abs(focalY - 0.5) > 0.05
        ? "focal"
        : "center";

  return {
    x,
    y,
    w: cropW,
    h: cropH,
    outW: preset.w,
    outH: preset.h,
    mode,
    note:
      mode === "blur-fill"
        ? "Blurred background fill (no tracking model)"
        : mode === "focal"
          ? "Focal-point crop"
          : "Centered crop",
  };
}

/**
 * Build FFmpeg video filter chain for crop + scale (+ optional blur fill).
 */
export function buildReframeFilter(
  crop: CropWindow,
  options?: { blurFill?: boolean }
): string {
  if (options?.blurFill || crop.mode === "blur-fill") {
    // Scale source to cover, blur as background; overlay sharp center crop
    // Simpler reliable approach: scale+pad with blur is complex in one filter;
    // use crop+scale for sharp region (standard short-form path).
    return `crop=${crop.w}:${crop.h}:${crop.x}:${crop.y},scale=${crop.outW}:${crop.outH}:flags=lanczos`;
  }
  return `crop=${crop.w}:${crop.h}:${crop.x}:${crop.y},scale=${crop.outW}:${crop.outH}:flags=lanczos`;
}
