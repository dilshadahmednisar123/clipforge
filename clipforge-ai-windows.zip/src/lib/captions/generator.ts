/**
 * Caption / subtitle generation for ClipForge.
 * Produces SRT, VTT, and FFmpeg-compatible ASS for burn-in.
 */

import type { TranscriptSegment, TranscriptWord } from "@/types";

export type CaptionStyleId =
  | "minimal-clean"
  | "bold-social"
  | "karaoke"
  | "word-emphasis"
  | "creator-podcast"
  | "high-contrast";

export interface CaptionStyle {
  id: CaptionStyleId;
  label: string;
  fontName: string;
  fontSize: number;
  primaryColor: string; // ASS &HBBGGRR
  outlineColor: string;
  backColor: string;
  bold: boolean;
  outline: number;
  shadow: number;
  alignment: number; // ASS: 2 = bottom center
  marginV: number;
  maxCharsPerLine: number;
}

export const CAPTION_STYLES: CaptionStyle[] = [
  {
    id: "minimal-clean",
    label: "Minimal Clean",
    fontName: "Arial",
    fontSize: 42,
    primaryColor: "&H00FFFFFF",
    outlineColor: "&H00000000",
    backColor: "&H80000000",
    bold: false,
    outline: 1,
    shadow: 0,
    alignment: 2,
    marginV: 48,
    maxCharsPerLine: 36,
  },
  {
    id: "bold-social",
    label: "Bold Social",
    fontName: "Arial Black",
    fontSize: 48,
    primaryColor: "&H00FFFFFF",
    outlineColor: "&H00000000",
    backColor: "&H00000000",
    bold: true,
    outline: 3,
    shadow: 1,
    alignment: 2,
    marginV: 56,
    maxCharsPerLine: 28,
  },
  {
    id: "karaoke",
    label: "Karaoke Highlight",
    fontName: "Arial",
    fontSize: 46,
    primaryColor: "&H0000FFFF", // cyan accent when active
    outlineColor: "&H00000000",
    backColor: "&H80000000",
    bold: true,
    outline: 2,
    shadow: 0,
    alignment: 2,
    marginV: 52,
    maxCharsPerLine: 30,
  },
  {
    id: "word-emphasis",
    label: "Word Emphasis",
    fontName: "Arial",
    fontSize: 44,
    primaryColor: "&H00FFFFFF",
    outlineColor: "&H00000000",
    backColor: "&H00000000",
    bold: true,
    outline: 2,
    shadow: 1,
    alignment: 2,
    marginV: 50,
    maxCharsPerLine: 32,
  },
  {
    id: "creator-podcast",
    label: "Creator / Podcast",
    fontName: "Georgia",
    fontSize: 40,
    primaryColor: "&H00F0F0F0",
    outlineColor: "&H00202020",
    backColor: "&HB0000000",
    bold: false,
    outline: 1,
    shadow: 0,
    alignment: 2,
    marginV: 64,
    maxCharsPerLine: 40,
  },
  {
    id: "high-contrast",
    label: "High Contrast A11y",
    fontName: "Arial",
    fontSize: 50,
    primaryColor: "&H0000FFFF",
    outlineColor: "&H00000000",
    backColor: "&HE0000000",
    bold: true,
    outline: 3,
    shadow: 0,
    alignment: 2,
    marginV: 48,
    maxCharsPerLine: 26,
  },
];

export function getStyle(id: string): CaptionStyle {
  return CAPTION_STYLES.find((s) => s.id === id) || CAPTION_STYLES[1];
}

/** Format seconds → SRT timestamp */
export function toSrtTime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const ms = Math.round((sec % 1) * 1000);
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms, 3)}`;
}

/** Format seconds → VTT / ASS timestamp */
export function toVttTime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const ms = Math.round((sec % 1) * 1000);
  return `${pad(h)}:${pad(m)}:${pad(s)}.${pad(ms, 3)}`;
}

function pad(n: number, len = 2): string {
  return String(n).padStart(len, "0");
}

function wrapLines(text: string, maxChars: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    if (!cur) {
      cur = w;
    } else if ((cur + " " + w).length <= maxChars) {
      cur += " " + w;
    } else {
      lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 3); // max 3 lines for vertical safety
}

/**
 * Slice transcript segments to a clip window [start, end].
 * Times are shifted so clip starts at 0.
 */
export function sliceTranscriptForClip(
  segments: TranscriptSegment[],
  clipStart: number,
  clipEnd: number
): TranscriptSegment[] {
  const out: TranscriptSegment[] = [];
  for (const seg of segments) {
    if (seg.end <= clipStart || seg.start >= clipEnd) continue;
    const start = Math.max(0, seg.start - clipStart);
    const end = Math.min(clipEnd - clipStart, seg.end - clipStart);
    if (end - start < 0.05) continue;

    let words: TranscriptWord[] | undefined;
    if (seg.words?.length) {
      words = seg.words
        .filter((w) => w.end > clipStart && w.start < clipEnd)
        .map((w) => ({
          ...w,
          start: Math.max(0, w.start - clipStart),
          end: Math.min(clipEnd - clipStart, w.end - clipStart),
        }));
    }

    out.push({
      id: seg.id,
      start,
      end,
      text: seg.text,
      speaker: seg.speaker,
      words,
    });
  }
  return out;
}

export function generateSRT(
  segments: TranscriptSegment[],
  style: CaptionStyle
): string {
  const blocks: string[] = [];
  let idx = 1;
  for (const seg of segments) {
    if (!seg.text.trim()) continue;
    const lines = wrapLines(seg.text.trim(), style.maxCharsPerLine);
    blocks.push(
      `${idx}\n${toSrtTime(seg.start)} --> ${toSrtTime(seg.end)}\n${lines.join("\n")}\n`
    );
    idx++;
  }
  return blocks.join("\n");
}

export function generateVTT(
  segments: TranscriptSegment[],
  style: CaptionStyle
): string {
  const blocks = ["WEBVTT", ""];
  for (const seg of segments) {
    if (!seg.text.trim()) continue;
    const lines = wrapLines(seg.text.trim(), style.maxCharsPerLine);
    blocks.push(
      `${toVttTime(seg.start)} --> ${toVttTime(seg.end)}\n${lines.join("\n")}\n`
    );
  }
  return blocks.join("\n");
}

/**
 * Generate ASS subtitle file for FFmpeg burn-in.
 * Supports basic karaoke when word timestamps exist and style is karaoke.
 */
export function generateASS(
  segments: TranscriptSegment[],
  style: CaptionStyle,
  playResX = 1080,
  playResY = 1920
): string {
  const header = `[Script Info]
Title: ClipForge Captions
ScriptType: v4.00+
PlayResX: ${playResX}
PlayResY: ${playResY}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,${style.fontName},${style.fontSize},${style.primaryColor},&H000000FF,${style.outlineColor},${style.backColor},${style.bold ? -1 : 0},0,0,0,100,100,0,0,1,${style.outline},${style.shadow},${style.alignment},40,40,${style.marginV},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const events: string[] = [];
  for (const seg of segments) {
    if (!seg.text.trim()) continue;
    const start = toAssTime(seg.start);
    const end = toAssTime(seg.end);

    if (
      (style.id === "karaoke" || style.id === "word-emphasis") &&
      seg.words &&
      seg.words.length > 0
    ) {
      // Karaoke: highlight word-by-word with \k tags (centiseconds)
      let karaokeText = "";
      let prevEnd = seg.start;
      for (const w of seg.words) {
        const gap = Math.max(0, w.start - prevEnd);
        if (gap > 0.05) {
          karaokeText += `{\\k${Math.round(gap * 100)}} `;
        }
        const dur = Math.max(1, Math.round((w.end - w.start) * 100));
        karaokeText += `{\\k${dur}}${escapeAss(w.word.trim())} `;
        prevEnd = w.end;
      }
      events.push(
        `Dialogue: 0,${start},${end},Default,,0,0,0,,${karaokeText.trim()}`
      );
    } else {
      const lines = wrapLines(seg.text.trim(), style.maxCharsPerLine);
      const text = lines.map(escapeAss).join("\\N");
      events.push(`Dialogue: 0,${start},${end},Default,,0,0,0,,${text}`);
    }
  }

  return header + events.join("\n") + "\n";
}

function toAssTime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const cs = Math.round((sec % 1) * 100);
  return `${h}:${pad(m)}:${pad(s)}.${pad(cs)}`;
}

function escapeAss(text: string): string {
  return text.replace(/\\/g, "\\\\").replace(/\{/g, "\\{").replace(/\}/g, "\\}");
}
