/**
 * Local storage usage scanning (uploads, exports, temp, models, data).
 */

import { promises as fs } from "fs";
import path from "path";

export interface StorageReport {
  totalBytes: number;
  breakdown: Record<string, number>;
  paths: Record<string, string>;
}

async function dirSize(dir: string): Promise<number> {
  let total = 0;
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        total += await dirSize(full);
      } else if (e.isFile()) {
        try {
          const st = await fs.stat(full);
          total += st.size;
        } catch {
          /* skip */
        }
      }
    }
  } catch {
    /* missing dir */
  }
  return total;
}

export async function getStorageReport(): Promise<StorageReport> {
  const root = process.cwd();
  const dirs: Record<string, string> = {
    uploads: path.join(root, "storage", "uploads"),
    exports: path.join(root, "storage", "exports"),
    temp: path.join(root, "storage", "temp"),
    models: path.join(root, "storage", "models"),
    data: path.join(root, "data"),
  };

  const breakdown: Record<string, number> = {};
  let totalBytes = 0;
  for (const [name, p] of Object.entries(dirs)) {
    const size = await dirSize(p);
    breakdown[name] = size;
    totalBytes += size;
  }

  return { totalBytes, breakdown, paths: dirs };
}

export async function clearTempFiles(): Promise<{ removed: number; bytes: number }> {
  const tempDir = path.join(process.cwd(), "storage", "temp");
  let removed = 0;
  let bytes = 0;
  try {
    const entries = await fs.readdir(tempDir, { withFileTypes: true });
    for (const e of entries) {
      if (e.name === ".gitkeep") continue;
      const full = path.join(tempDir, e.name);
      try {
        const st = await fs.stat(full);
        bytes += st.size;
        await fs.rm(full, { recursive: true, force: true });
        removed++;
      } catch {
        /* skip */
      }
    }
  } catch {
    /* empty */
  }
  return { removed, bytes };
}

/**
 * List model-related files under storage/models and common cache locations.
 */
export async function listLocalModels(): Promise<
  Array<{ name: string; path: string; size: number }>
> {
  const modelsDir = path.join(process.cwd(), "storage", "models");
  const results: Array<{ name: string; path: string; size: number }> = [];

  async function walk(dir: string, prefix = "") {
    try {
      const entries = await fs.readdir(dir, { withFileTypes: true });
      for (const e of entries) {
        const full = path.join(dir, e.name);
        if (e.isDirectory()) {
          await walk(full, prefix ? `${prefix}/${e.name}` : e.name);
        } else if (e.isFile() && e.name !== ".gitkeep") {
          const st = await fs.stat(full);
          results.push({
            name: prefix ? `${prefix}/${e.name}` : e.name,
            path: full,
            size: st.size,
          });
        }
      }
    } catch {
      /* missing */
    }
  }

  await walk(modelsDir);
  return results.sort((a, b) => b.size - a.size);
}
