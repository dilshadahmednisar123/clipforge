/**
 * ClipForge local persistence — atomic JSON files under data/
 * On Vercel, uses /tmp/clipforge (ephemeral).
 */

import { promises as fs } from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { dataRoot } from "@/lib/platform";
import type {
  Project,
  ClipCandidate,
  TranscriptSegment,
  Job,
  JobStatus,
  MediaMetadata,
  ProjectSettings,
} from "@/types";

function paths() {
  const root = dataRoot();
  const DATA_DIR = path.join(root, "data");
  return {
    DATA_DIR,
    PROJECTS_FILE: path.join(DATA_DIR, "projects.json"),
    JOBS_FILE: path.join(DATA_DIR, "jobs.json"),
    TRANSCRIPTS_DIR: path.join(DATA_DIR, "transcripts"),
    CLIPS_DIR: path.join(DATA_DIR, "clips"),
    UPLOADS_DIR: path.join(root, "storage", "uploads"),
  };
}

async function ensureDirs() {
  const p = paths();
  await fs.mkdir(p.DATA_DIR, { recursive: true });
  await fs.mkdir(p.TRANSCRIPTS_DIR, { recursive: true });
  await fs.mkdir(p.CLIPS_DIR, { recursive: true });
  await fs.mkdir(p.UPLOADS_DIR, { recursive: true });
}

async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    const raw = await fs.readFile(file, "utf-8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

async function writeJsonAtomic(file: string, data: unknown) {
  await ensureDirs();
  const tmp = `${file}.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data, null, 2), "utf-8");
  await fs.rename(tmp, file);
}

// ── Projects ──────────────────────────────────────────────────────────────

export async function listProjects(): Promise<Project[]> {
  const { PROJECTS_FILE } = paths();
  const projects = await readJson<Project[]>(PROJECTS_FILE, []);
  return projects.sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

export async function getProject(id: string): Promise<Project | null> {
  const { PROJECTS_FILE } = paths();
  const projects = await readJson<Project[]>(PROJECTS_FILE, []);
  return projects.find((p) => p.id === id) ?? null;
}

export async function createProject(input: {
  name: string;
  sourcePath: string;
  sourceFilename: string;
  metadata?: MediaMetadata;
  settings?: Partial<ProjectSettings>;
}): Promise<Project> {
  const { PROJECTS_FILE } = paths();
  const projects = await readJson<Project[]>(PROJECTS_FILE, []);
  const now = new Date().toISOString();
  const project: Project = {
    id: randomUUID(),
    name: input.name,
    sourcePath: input.sourcePath,
    sourceFilename: input.sourceFilename,
    metadata: input.metadata,
    status: "QUEUED",
    createdAt: now,
    updatedAt: now,
    clipCount: 0,
    exportCount: 0,
    settings: {
      targetClipCount: 5,
      minClipDuration: 15,
      maxClipDuration: 60,
      aspectRatio: "9:16",
      captionStyle: "bold-social",
      ...input.settings,
    },
  };
  projects.push(project);
  await writeJsonAtomic(PROJECTS_FILE, projects);
  return project;
}

export async function updateProject(
  id: string,
  patch: Partial<Project>
): Promise<Project | null> {
  const { PROJECTS_FILE } = paths();
  const projects = await readJson<Project[]>(PROJECTS_FILE, []);
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return null;
  projects[idx] = {
    ...projects[idx],
    ...patch,
    updatedAt: new Date().toISOString(),
  };
  await writeJsonAtomic(PROJECTS_FILE, projects);
  return projects[idx];
}

export async function deleteProject(id: string): Promise<boolean> {
  const { PROJECTS_FILE, TRANSCRIPTS_DIR, CLIPS_DIR } = paths();
  const projects = await readJson<Project[]>(PROJECTS_FILE, []);
  const next = projects.filter((p) => p.id !== id);
  if (next.length === projects.length) return false;
  await writeJsonAtomic(PROJECTS_FILE, next);
  try {
    await fs.unlink(path.join(TRANSCRIPTS_DIR, `${id}.json`));
  } catch {
    /* ignore */
  }
  try {
    await fs.unlink(path.join(CLIPS_DIR, `${id}.json`));
  } catch {
    /* ignore */
  }
  return true;
}

// ── Transcripts ───────────────────────────────────────────────────────────

export async function saveTranscript(
  projectId: string,
  segments: TranscriptSegment[]
): Promise<void> {
  const { TRANSCRIPTS_DIR } = paths();
  await ensureDirs();
  await writeJsonAtomic(path.join(TRANSCRIPTS_DIR, `${projectId}.json`), {
    projectId,
    segments,
    savedAt: new Date().toISOString(),
  });
}

export async function getTranscript(
  projectId: string
): Promise<TranscriptSegment[] | null> {
  const { TRANSCRIPTS_DIR } = paths();
  try {
    const data = await readJson<{ segments: TranscriptSegment[] }>(
      path.join(TRANSCRIPTS_DIR, `${projectId}.json`),
      { segments: [] }
    );
    return data.segments.length ? data.segments : null;
  } catch {
    return null;
  }
}

// ── Clips ─────────────────────────────────────────────────────────────────

export async function saveClips(
  projectId: string,
  clips: ClipCandidate[]
): Promise<void> {
  const { CLIPS_DIR } = paths();
  await ensureDirs();
  await writeJsonAtomic(path.join(CLIPS_DIR, `${projectId}.json`), {
    projectId,
    clips,
    savedAt: new Date().toISOString(),
  });
  await updateProject(projectId, { clipCount: clips.length });
}

export async function getClips(
  projectId: string
): Promise<ClipCandidate[] | null> {
  const { CLIPS_DIR } = paths();
  try {
    const data = await readJson<{ clips: ClipCandidate[] }>(
      path.join(CLIPS_DIR, `${projectId}.json`),
      { clips: [] }
    );
    return data.clips.length ? data.clips : null;
  } catch {
    return null;
  }
}

export async function updateClip(
  projectId: string,
  clipId: string,
  patch: Partial<ClipCandidate>
): Promise<ClipCandidate | null> {
  const clips = (await getClips(projectId)) ?? [];
  const idx = clips.findIndex((c) => c.id === clipId);
  if (idx === -1) return null;
  clips[idx] = { ...clips[idx], ...patch };
  await saveClips(projectId, clips);
  return clips[idx];
}

// ── Jobs ──────────────────────────────────────────────────────────────────

export async function listJobs(projectId?: string): Promise<Job[]> {
  const { JOBS_FILE } = paths();
  const jobs = await readJson<Job[]>(JOBS_FILE, []);
  const filtered = projectId
    ? jobs.filter((j) => j.projectId === projectId)
    : jobs;
  return filtered.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export async function getJob(id: string): Promise<Job | null> {
  const { JOBS_FILE } = paths();
  const jobs = await readJson<Job[]>(JOBS_FILE, []);
  return jobs.find((j) => j.id === id) ?? null;
}

export async function createJob(input: {
  projectId: string;
  type: string;
}): Promise<Job> {
  const { JOBS_FILE } = paths();
  const jobs = await readJson<Job[]>(JOBS_FILE, []);
  const now = new Date().toISOString();
  const job: Job = {
    id: randomUUID(),
    projectId: input.projectId,
    type: input.type,
    status: "QUEUED",
    progress: 0,
    stage: "QUEUED",
    createdAt: now,
    updatedAt: now,
  };
  jobs.push(job);
  await writeJsonAtomic(JOBS_FILE, jobs);
  return job;
}

export async function updateJob(
  id: string,
  patch: Partial<Job>
): Promise<Job | null> {
  const { JOBS_FILE } = paths();
  const jobs = await readJson<Job[]>(JOBS_FILE, []);
  const idx = jobs.findIndex((j) => j.id === id);
  if (idx === -1) return null;
  jobs[idx] = {
    ...jobs[idx],
    ...patch,
    updatedAt: new Date().toISOString(),
  };
  await writeJsonAtomic(JOBS_FILE, jobs);
  return jobs[idx];
}

export async function setJobStatus(
  id: string,
  status: JobStatus,
  extra?: Partial<Job>
): Promise<Job | null> {
  return updateJob(id, { status, stage: status, ...extra });
}
