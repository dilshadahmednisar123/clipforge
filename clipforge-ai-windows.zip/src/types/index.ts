export type JobStatus =
  | "QUEUED"
  | "VALIDATING"
  | "TRANSCRIBING"
  | "ANALYZING"
  | "SELECTING_CLIPS"
  | "REFRAMING"
  | "CAPTIONING"
  | "RENDERING"
  | "VERIFYING"
  | "COMPLETED"
  | "FAILED"
  | "CANCELLED";

export interface MediaMetadata {
  duration: number;
  width: number;
  height: number;
  fps: number;
  codec: string;
  audioCodec?: string;
  bitrate?: number;
  size: number;
  format: string;
  hasAudio: boolean;
  hasVideo: boolean;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  sourcePath: string;
  sourceFilename: string;
  thumbnailPath?: string;
  metadata?: MediaMetadata;
  status: JobStatus;
  createdAt: string;
  updatedAt: string;
  clipCount: number;
  exportCount: number;
  settings?: ProjectSettings;
}

export interface ProjectSettings {
  targetClipCount: number;
  minClipDuration: number;
  maxClipDuration: number;
  aspectRatio: "9:16" | "1:1" | "4:5" | "16:9";
  captionStyle: string;
  language?: string;
}

export interface ClipCandidate {
  id: string;
  projectId: string;
  start: number;
  end: number;
  score: number;
  title?: string;
  summary?: string;
  scoreBreakdown?: Record<string, number>;
  selected: boolean;
  aspectRatio?: string;
  captionPath?: string;
  exportPath?: string;
}

export interface TranscriptSegment {
  id: string;
  start: number;
  end: number;
  text: string;
  speaker?: string;
  words?: TranscriptWord[];
}

export interface TranscriptWord {
  word: string;
  start: number;
  end: number;
  confidence?: number;
}

export interface Job {
  id: string;
  projectId: string;
  type: string;
  status: JobStatus;
  progress: number;
  stage: string;
  message?: string;
  error?: string;
  createdAt: string;
  updatedAt: string;
  startedAt?: string;
  finishedAt?: string;
}

export interface AppMode {
  mode: "browser-lite" | "full-local";
  ffmpegAvailable: boolean;
  workerAvailable: boolean;
  models: {
    whisper: boolean;
    whisperSize?: string;
  };
  storagePath: string;
  storageUsed: number;
}
