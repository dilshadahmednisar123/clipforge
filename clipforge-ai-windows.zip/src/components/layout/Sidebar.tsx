"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Scissors,
  Film,
  FolderOpen,
  Download,
  Cpu,
  Settings,
  Library,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/create", label: "Create Clips", icon: Scissors },
  { href: "/editor", label: "Editor", icon: Film },
  { href: "/library", label: "Media Library", icon: Library },
  { href: "/projects", label: "Projects", icon: FolderOpen },
  { href: "/exports", label: "Export Queue", icon: Download },
  { href: "/models", label: "Model Manager", icon: Cpu },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex w-56 flex-col border-r border-border bg-card">
      <div className="flex h-14 items-center gap-2 border-b border-border px-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-violet-600">
          <Scissors className="h-4 w-4 text-white" />
        </div>
        <div>
          <span className="text-sm font-semibold tracking-tight">ClipForge</span>
          <span className="ml-1 text-xs text-cyan-400">AI</span>
        </div>
      </div>
      <nav className="flex-1 space-y-1 p-3">
        {navItems.map((item) => {
          const active =
            pathname === item.href ||
            (item.href !== "/" && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-primary/15 text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-border p-3">
        <div className="rounded-md bg-muted/50 px-3 py-2 text-xs text-muted-foreground">
          <div className="font-medium text-foreground/80">Mode</div>
          <div className="mt-0.5 flex items-center gap-1.5">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-amber-400" />
            Browser Lite
          </div>
        </div>
      </div>
    </aside>
  );
}
