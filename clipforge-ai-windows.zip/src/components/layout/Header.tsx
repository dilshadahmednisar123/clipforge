"use client";

import { Bell, HardDrive } from "lucide-react";

export function Header() {
  return (
    <header className="flex h-14 items-center justify-between border-b border-border bg-card/50 px-4 md:px-6">
      <div className="md:hidden flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-violet-600">
          <span className="text-xs font-bold text-white">CF</span>
        </div>
        <span className="text-sm font-semibold">ClipForge AI</span>
      </div>
      <div className="hidden md:block text-sm text-muted-foreground">
        Local-first video repurposing
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 rounded-md bg-muted/60 px-2.5 py-1 text-xs text-muted-foreground">
          <HardDrive className="h-3.5 w-3.5" />
          <span>Local storage</span>
        </div>
        <button
          type="button"
          className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
          aria-label="Notifications"
        >
          <Bell className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
