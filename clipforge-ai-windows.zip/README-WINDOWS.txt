ClipForge AI — Windows
======================

This is a WORKING local desktop app (not a fake single .exe cloud demo).
It uses Electron + your installed Node.js + system FFmpeg.

REQUIREMENTS
------------
1. Node.js 20 LTS  https://nodejs.org  (install with default PATH options)
2. FFmpeg          Open PowerShell as user and run:
                     winget install ffmpeg
                   Or download from https://ffmpeg.org and add to PATH
3. (Optional) Python 3.10+ for speech-to-text (Whisper)

FIRST RUN
---------
1. Unzip this folder anywhere (e.g. Desktop\clipforge-ai)
2. Double-click:
     scripts\windows\INSTALL-AND-RUN.bat
3. Wait for npm install, then the ClipForge window opens

LATER RUNS
----------
  scripts\windows\RUN-DESKTOP.bat

OPTIONAL — real transcription
-----------------------------
  scripts\windows\START-WORKER.bat
(keep that window open, then use Analyze in the app)

WEB UI INSTEAD OF DESKTOP WINDOW
--------------------------------
  Open a terminal in this folder:
    npm run dev
  Browser: http://localhost:3000

BUILD A REAL .EXE INSTALLER (on a Windows PC)
---------------------------------------------
  npm install
  npm run setup
  npm run desktop:dist
Output: dist-desktop\  (NSIS installer via electron-builder)

The packaged installer still expects FFmpeg on the system PATH unless you
bundle FFmpeg binaries yourself later.

IF SOMETHING FAILS
------------------
- "node is not recognized" → install Node.js and restart the PC
- Validate / export errors → install FFmpeg, restart terminal/app
- Blank Electron window → run INSTALL-AND-RUN.bat again; allow firewall for Node
- Transcription is fake placeholders → start START-WORKER.bat

SUPPORT DOCS (in this zip)
--------------------------
  docs\DESKTOP.md
  docs\INSTALL.md
  docs\FREE-DEPLOY.md
