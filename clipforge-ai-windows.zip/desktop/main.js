/**
 * ClipForge AI — Electron main process
 * Starts the local Next.js server, then opens a desktop window.
 */

const { app, BrowserWindow, shell, dialog } = require("electron");
const { spawn } = require("child_process");
const path = require("path");
const http = require("http");

const PORT = process.env.PORT || 3000;
const isDev = !app.isPackaged;

let mainWindow = null;
let serverProcess = null;

function projectRoot() {
  // In dev: repo root (parent of desktop/)
  // In packaged app: resources path
  if (isDev) {
    return path.join(__dirname, "..");
  }
  return process.resourcesPath;
}

function waitForServer(url, attempts = 60) {
  return new Promise((resolve, reject) => {
    let n = 0;
    const tick = () => {
      n++;
      const req = http.get(url, (res) => {
        res.resume();
        resolve();
      });
      req.on("error", () => {
        if (n >= attempts) reject(new Error("Server did not start in time"));
        else setTimeout(tick, 500);
      });
    };
    tick();
  });
}

function startNextServer() {
  const root = projectRoot();
  const npmCmd = process.platform === "win32" ? "npm.cmd" : "npm";
  const args = isDev ? ["run", "dev", "--", "-p", String(PORT)] : ["run", "start", "--", "-p", String(PORT)];

  serverProcess = spawn(npmCmd, args, {
    cwd: root,
    env: {
      ...process.env,
      PORT: String(PORT),
      BROWSER: "none",
    },
    shell: false,
    stdio: "inherit",
  });

  serverProcess.on("error", (err) => {
    dialog.showErrorBox(
      "ClipForge failed to start",
      `Could not start the local server.\n\n${err.message}\n\nIs Node.js installed? Run npm install in the project folder first.`
    );
  });

  serverProcess.on("exit", (code) => {
    if (code && code !== 0 && mainWindow) {
      dialog.showErrorBox(
        "Server exited",
        `The ClipForge server stopped (code ${code}). Close the app and try again.`
      );
    }
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: "ClipForge AI",
    backgroundColor: "#0b0f17",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
    show: false,
  });

  mainWindow.once("ready-to-show", () => mainWindow.show());

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });

  mainWindow.loadURL(`http://127.0.0.1:${PORT}`);
}

async function boot() {
  startNextServer();
  try {
    await waitForServer(`http://127.0.0.1:${PORT}`);
  } catch (e) {
    dialog.showErrorBox(
      "ClipForge server timeout",
      `${e.message}\n\nRun: npm install && npm run setup\nThen try again.`
    );
    app.quit();
    return;
  }
  createWindow();
}

app.whenReady().then(boot);

app.on("window-all-closed", () => {
  if (serverProcess && !serverProcess.killed) {
    serverProcess.kill("SIGTERM");
  }
  if (process.platform !== "darwin") app.quit();
});

app.on("before-quit", () => {
  if (serverProcess && !serverProcess.killed) {
    serverProcess.kill("SIGTERM");
  }
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
