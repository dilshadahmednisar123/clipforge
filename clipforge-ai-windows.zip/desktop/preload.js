/**
 * Preload — keep isolated; expose nothing sensitive by default.
 * Future: desktop-specific APIs (pick folder, show item in folder).
 */
const { contextBridge } = require("electron");

contextBridge.exposeInMainWorld("clipforgeDesktop", {
  isDesktop: true,
  platform: process.platform,
});
