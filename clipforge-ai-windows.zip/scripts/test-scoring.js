/**
 * Quick scoring engine smoke test (no Next.js required).
 * Run: node scripts/test-scoring.js
 */

// Minimal inline re-implementation of core scoring checks for CI-less verification
function wordCount(text) {
  return text.split(/\s+/).filter(Boolean).length;
}

function hasIncompleteEnd(text) {
  const t = text.trim();
  if (!t) return true;
  return !/[.!?]\s*$/.test(t);
}

const segments = [
  { id: "1", start: 0, end: 4, text: "Why do most people fail at this?" },
  { id: "2", start: 4.2, end: 9, text: "The secret is consistency and focus every single day." },
  { id: "3", start: 10, end: 14, text: "You need to stop making excuses right now." },
  { id: "4", start: 15, end: 20, text: "And that is how you actually win." },
  { id: "5", start: 25, end: 28, text: "um uh" },
];

let passed = 0;
let failed = 0;

function assert(cond, msg) {
  if (cond) {
    passed++;
    console.log("  ✓", msg);
  } else {
    failed++;
    console.log("  ✗", msg);
  }
}

console.log("\nClipForge scoring smoke tests\n");

assert(wordCount(segments[0].text) === 7, "word count on first segment");
assert(!hasIncompleteEnd(segments[0].text), "question ends cleanly");
assert(hasIncompleteEnd("this is incomplete"), "detects incomplete sentence");
assert(segments.length === 5, "fixture has 5 segments");

// Duration window logic
const minD = 15;
const maxD = 60;
const totalEnd = Math.max(...segments.map((s) => s.end));
assert(totalEnd === 28, "total end is 28s");
assert(minD < maxD, "duration range valid");

// Silence-ish segment should score lower conceptually
const fillerWords = wordCount(segments[4].text);
assert(fillerWords <= 2, "filler segment has few words");

console.log(`\n${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
