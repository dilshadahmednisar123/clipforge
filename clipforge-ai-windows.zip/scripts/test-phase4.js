/**
 * Phase 4 smoke tests: queue concurrency bounds, terminal status helpers.
 * Run: node scripts/test-phase4.js
 */

function isTerminal(status) {
  return status === "COMPLETED" || status === "FAILED" || status === "CANCELLED";
}

let passed = 0;
let failed = 0;
function assert(cond, msg) {
  if (cond) {
    passed++;
    console.log("  ✓", msg);
  } else {
    failed++;
    console.log("  ✗", msg);
  }
}

console.log("\nClipForge Phase 4 smoke tests\n");

assert(isTerminal("COMPLETED"), "COMPLETED is terminal");
assert(isTerminal("FAILED"), "FAILED is terminal");
assert(isTerminal("CANCELLED"), "CANCELLED is terminal");
assert(!isTerminal("RENDERING"), "RENDERING is not terminal");
assert(!isTerminal("QUEUED"), "QUEUED is not terminal");

// Bounded queue simulation
const MAX = 1;
let active = 0;
const wait = [];
const results = [];

function pump() {
  while (active < MAX && wait.length) {
    const job = wait.shift();
    active++;
    // sync "run"
    results.push(job);
    active--;
  }
}

wait.push("a", "b", "c");
pump();
assert(results.length === 3, "queue drains all jobs");
assert(results[0] === "a" && results[2] === "c", "FIFO order");

// Cancel before start
const cancelled = new Set(["x"]);
const queue2 = ["x", "y"].filter((id) => !cancelled.has(id));
assert(queue2.length === 1 && queue2[0] === "y", "cancelled job skipped");

// Path safety for downloads
function safeBasename(file) {
  const base = file.replace(/^.*[/\\]/, "");
  if (base !== file.replace(/\\/g, "/").split("/").pop()) return null;
  if (base.includes("..")) return null;
  return base;
}
assert(safeBasename("clip_abc.mp4") === "clip_abc.mp4", "safe basename ok");
assert(safeBasename("../etc/passwd") !== "../etc/passwd", "traversal rejected");

console.log(`\n${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
