/**
 * Phase 3 smoke tests: captions + crop math (no FFmpeg required).
 * Run: node scripts/test-phase3.js
 */

function pad(n, len = 2) {
  return String(n).padStart(len, "0");
}

function toSrtTime(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const ms = Math.round((sec % 1) * 1000);
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms, 3)}`;
}

function computeCrop(srcW, srcH, targetW, targetH, focalX = 0.5, focalY = 0.5) {
  const targetRatio = targetW / targetH;
  const srcRatio = srcW / srcH;
  let cropW, cropH;
  if (srcRatio > targetRatio) {
    cropH = srcH;
    cropW = Math.round(srcH * targetRatio);
  } else {
    cropW = srcW;
    cropH = Math.round(srcW / targetRatio);
  }
  let x = Math.round(focalX * srcW - cropW / 2);
  let y = Math.round(focalY * srcH - cropH / 2);
  x = Math.max(0, Math.min(srcW - cropW, x));
  y = Math.max(0, Math.min(srcH - cropH, y));
  return { x, y, w: cropW, h: cropH };
}

function wrapLines(text, maxChars) {
  const words = text.split(/\s+/).filter(Boolean);
  const lines = [];
  let cur = "";
  for (const w of words) {
    if (!cur) cur = w;
    else if ((cur + " " + w).length <= maxChars) cur += " " + w;
    else {
      lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 3);
}

let passed = 0;
let failed = 0;
function assert(cond, msg) {
  if (cond) {
    passed++;
    console.log("  ✓", msg);
  } else {
    failed++;
    console.log("  ✗", msg);
  }
}

console.log("\nClipForge Phase 3 smoke tests\n");

// SRT timestamps
assert(toSrtTime(0) === "00:00:00,000", "SRT zero");
assert(toSrtTime(65.5) === "00:01:05,500", "SRT 65.5s");
assert(toSrtTime(3661.25).startsWith("01:01:01"), "SRT > 1h");

// Crop: 1920x1080 → 9:16
const c1 = computeCrop(1920, 1080, 1080, 1920);
assert(c1.h === 1080, "9:16 crop height = source height");
assert(c1.w < 1920, "9:16 crop width < source width");
assert(Math.abs(c1.w / c1.h - 1080 / 1920) < 0.02, "9:16 aspect preserved");
assert(c1.x >= 0 && c1.x + c1.w <= 1920, "9:16 crop in bounds");

// Crop: 1920x1080 → 1:1
const c2 = computeCrop(1920, 1080, 1080, 1080);
assert(c2.w === c2.h, "1:1 square crop");
assert(c2.h === 1080, "1:1 uses full height");

// Focal point shifts crop
const c3 = computeCrop(1920, 1080, 1080, 1920, 0.2, 0.5);
const c4 = computeCrop(1920, 1080, 1080, 1920, 0.8, 0.5);
assert(c3.x < c4.x, "focal X shifts crop left vs right");

// Line wrap
const lines = wrapLines("Why do most people fail at building habits every day", 20);
assert(lines.length >= 2, "wrap produces multiple lines");
assert(lines.every((l) => l.length <= 22), "lines respect max width");

// Path safety simulation
const bad = "../../etc/passwd";
const base = bad.split(/[/\\]/).pop();
assert(base === "passwd", "basename strips traversal");

console.log(`\n${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
