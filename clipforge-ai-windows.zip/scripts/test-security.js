/**
 * Security path helpers smoke tests.
 * Run: node scripts/test-security.js
 */

const path = require("path");

const SAFE_NAME = /^[a-zA-Z0-9._-]+$/;

function downloadBasename(input) {
  if (!input || typeof input !== "string") return null;
  if (input.includes("\0") || input.includes("..")) return null;
  if (/[/\\]/.test(input)) return null;
  if (!SAFE_NAME.test(input)) return null;
  return input;
}

function resolveUnderRoot(root, ...parts) {
  const rootResolved = path.resolve(root);
  const candidate = path.resolve(rootResolved, ...parts);
  if (
    candidate !== rootResolved &&
    !candidate.startsWith(rootResolved + path.sep)
  ) {
    return null;
  }
  return candidate;
}

function sanitizeUploadName(name, maxLen = 120) {
  const base = path.basename(name || "upload.bin");
  const cleaned = base.replace(/[^a-zA-Z0-9._-]/g, "_").replace(/_{2,}/g, "_");
  return cleaned.slice(0, maxLen) || "upload.bin";
}

function isAllowedVideoName(name) {
  return /\.(mp4|mov|mkv|webm|avi|m4v)$/i.test(name);
}

let passed = 0;
let failed = 0;
function assert(cond, msg) {
  if (cond) {
    passed++;
    console.log("  ✓", msg);
  } else {
    failed++;
    console.log("  ✗", msg);
  }
}

console.log("\nClipForge security smoke tests\n");

// downloadBasename
assert(downloadBasename("clip_abc.mp4") === "clip_abc.mp4", "plain name ok");
assert(downloadBasename("../etc/passwd") === null, "reject ../ traversal");
assert(downloadBasename("foo/bar.mp4") === null, "reject path separator");
assert(downloadBasename("foo\\bar.mp4") === null, "reject backslash");
assert(downloadBasename("a..b.mp4") === null, "reject embedded ..");
assert(downloadBasename("file name.mp4") === null, "reject spaces");
assert(downloadBasename("") === null, "reject empty");
assert(downloadBasename("clip.srt") === "clip.srt", "srt allowed pattern");

// resolveUnderRoot
const root = path.resolve("/tmp/clipforge-exports");
assert(
  resolveUnderRoot(root, "ok.mp4") === path.join(root, "ok.mp4"),
  "resolve under root"
);
assert(resolveUnderRoot(root, "..", "etc", "passwd") === null, "block .. escape");
assert(resolveUnderRoot(root, "/etc/passwd") === null, "block absolute inject");

// sanitizeUploadName
assert(
  sanitizeUploadName("../../evil.mp4") === "evil.mp4",
  "sanitize strips path"
);
assert(
  sanitizeUploadName("My Video (1).MP4").includes("MP4"),
  "keeps extension chars"
);
assert(isAllowedVideoName("talk.mp4"), "mp4 allowed");
assert(isAllowedVideoName("talk.exe") === false, "exe rejected");
assert(isAllowedVideoName("talk.webm"), "webm allowed");

// Job state machine
const terminals = new Set(["COMPLETED", "FAILED", "CANCELLED"]);
const stages = [
  "QUEUED",
  "VALIDATING",
  "TRANSCRIBING",
  "ANALYZING",
  "SELECTING_CLIPS",
  "REFRAMING",
  "CAPTIONING",
  "RENDERING",
  "VERIFYING",
  "COMPLETED",
  "FAILED",
  "CANCELLED",
];
assert(stages.length === 12, "12 job states defined");
assert(terminals.has("COMPLETED") && terminals.has("FAILED"), "terminals set");

console.log(`\n${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
