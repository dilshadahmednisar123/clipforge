@echo off
setlocal EnableExtensions
title ClipForge AI — Install and Run
cd /d "%~dp0..\.."

echo.
echo  ========================================
echo   ClipForge AI — Windows setup
echo  ========================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js is not installed or not on PATH.
  echo Download LTS from https://nodejs.org and install it.
  echo Then run this file again.
  echo.
  start https://nodejs.org
  pause
  exit /b 1
)

where ffmpeg >nul 2>&1
if errorlevel 1 (
  echo [WARN] FFmpeg not found on PATH.
  echo Video import/export will fail until you install FFmpeg.
  echo   winget install ffmpeg
  echo   or https://ffmpeg.org/download.html
  echo.
)

where ffprobe >nul 2>&1
if errorlevel 1 (
  echo [WARN] FFprobe not found on PATH.
  echo.

)

echo Node:
node -v
echo.
echo Installing npm dependencies (first run may take a few minutes)...
call npm install
if errorlevel 1 (
  echo [ERROR] npm install failed.
  pause
  exit /b 1
)

echo.
echo Running setup check...
call npm run setup

echo.
echo Starting desktop app...
echo (Optional: open another terminal and run  npm run worker  for Whisper STT)
echo.
call npm run desktop
if errorlevel 1 (
  echo.
  echo If Electron failed, try:  npm install electron --save-dev
  echo Then run this script again.
  pause
  exit /b 1
)

endlocal
