@echo off
setlocal
title ClipForge Worker (Whisper)
cd /d "%~dp0..\.."

where python >nul 2>&1
if errorlevel 1 (
  where python3 >nul 2>&1
  if errorlevel 1 (
    echo Python not found. Install Python 3.10+ from https://python.org
    echo Check "Add to PATH" during setup.
    pause
    exit /b 1
  )
  set PY=python3
) else (
  set PY=python
)

echo Installing Python packages if needed...
%PY% -m pip install fastapi "uvicorn[standard]" python-multipart faster-whisper
if errorlevel 1 (
  echo pip install failed.
  pause
  exit /b 1
)

set CLIPFORGE_WHISPER_SIZE=tiny
echo Starting worker on http://127.0.0.1:8765 ...
%PY% worker\main.py
pause
endlocal
