@echo off
setlocal
title ClipForge AI
cd /d "%~dp0..\.."

where node >nul 2>&1
if errorlevel 1 (
  echo Node.js not found. Run INSTALL-AND-RUN.bat first.
  pause
  exit /b 1
)

if not exist "node_modules\electron" (
  echo Electron not installed. Running INSTALL-AND-RUN.bat is recommended.
  echo Installing electron...
  call npm install electron --save-dev
)

echo Starting ClipForge desktop...
call npm run desktop
pause
endlocal
