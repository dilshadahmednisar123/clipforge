/**
 * Integration smoke test using a generated sample video (FFmpeg required).
 * Run: node scripts/test-integration.js
 */

const { execFile } = require("child_process");
const { promisify } = require("util");
const fs = require("fs");
const path = require("path");

const execFileAsync = promisify(execFile);
const root = path.join(__dirname, "..");
const sampleDir = path.join(root, "public", "samples");
const samplePath = path.join(sampleDir, "smoke-test.mp4");

let passed = 0;
let failed = 0;
function assert(cond, msg) {
  if (cond) {
    passed++;
    console.log("  ✓", msg);
  } else {
    failed++;
    console.log("  ✗", msg);
  }
}

async function main() {
  console.log("\nClipForge integration smoke tests\n");

  fs.mkdirSync(sampleDir, { recursive: true });

  // Generate 3s test pattern with sine tone
  try {
    await execFileAsync(
      "ffmpeg",
      [
        "-y",
        "-f",
        "lavfi",
        "-i",
        "testsrc=size=640x360:rate=30:duration=3",
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=440:duration=3",
        "-c:v",
        "libx264",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-shortest",
        samplePath,
      ],
      { timeout: 60000 }
    );
    assert(fs.existsSync(samplePath), "sample video created");
    const size = fs.statSync(samplePath).size;
    assert(size > 1000, `sample size > 1KB (${size} bytes)`);
  } catch (err) {
    assert(false, `ffmpeg sample generation: ${err.message}`);
    console.log(`\n${passed} passed, ${failed} failed\n`);
    process.exit(1);
  }

  // Probe
  try {
    const { stdout } = await execFileAsync(
      "ffprobe",
      [
        "-v",
        "quiet",
        "-print_format",
        "json",
        "-show_format",
        "-show_streams",
        samplePath,
      ],
      { timeout: 15000 }
    );
    const data = JSON.parse(stdout);
    const video = (data.streams || []).find((s) => s.codec_type === "video");
    const audio = (data.streams || []).find((s) => s.codec_type === "audio");
    const duration = Number(data.format?.duration) || 0;
    assert(Boolean(video), "probe finds video stream");
    assert(Boolean(audio), "probe finds audio stream");
    assert(duration >= 2.5 && duration <= 3.5, `duration ~3s (got ${duration})`);
    assert(video.width === 640 && video.height === 360, "resolution 640x360");
  } catch (err) {
    assert(false, `ffprobe: ${err.message}`);
  }

  // Trim + re-encode a 1s clip (export path smoke)
  const outClip = path.join(sampleDir, "smoke-clip.mp4");
  try {
    await execFileAsync(
      "ffmpeg",
      [
        "-y",
        "-ss",
        "0.5",
        "-i",
        samplePath,
        "-t",
        "1",
        "-vf",
        "crop=202:360:219:0,scale=1080:1920:flags=lanczos",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-crf",
        "28",
        "-c:a",
        "aac",
        "-b:a",
        "96k",
        "-pix_fmt",
        "yuv420p",
        outClip,
      ],
      { timeout: 60000 }
    );
    assert(fs.existsSync(outClip), "vertical clip rendered");
    const { stdout } = await execFileAsync(
      "ffprobe",
      ["-v", "quiet", "-print_format", "json", "-show_streams", outClip],
      { timeout: 15000 }
    );
    const data = JSON.parse(stdout);
    const video = (data.streams || []).find((s) => s.codec_type === "video");
    assert(video && video.width === 1080 && video.height === 1920, "output is 1080x1920");
  } catch (err) {
    assert(false, `clip render: ${err.message}`);
  }

  // Audio filter string builder (inline mirror)
  function buildAudioFilters(options, clipDuration) {
    const parts = [];
    if (options.loudnorm) parts.push("loudnorm=I=-14:TP=-1.5:LRA=11");
    if (options.fadeIn) parts.push(`afade=t=in:st=0:d=${options.fadeIn}`);
    if (options.fadeOut && clipDuration > options.fadeOut) {
      const st = clipDuration - options.fadeOut;
      parts.push(`afade=t=out:st=${st}:d=${options.fadeOut}`);
    }
    return parts.join(",");
  }
  const af = buildAudioFilters({ loudnorm: true, fadeIn: 0.1, fadeOut: 0.2 }, 5);
  assert(af.includes("loudnorm"), "audio filter includes loudnorm");
  assert(af.includes("afade"), "audio filter includes fade");

  console.log(`\n${passed} passed, ${failed} failed\n`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
