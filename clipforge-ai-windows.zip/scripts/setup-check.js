#!/usr/bin/env node
/**
 * ClipForge AI — first-run system check
 * Detects FFmpeg, Python worker deps, writable storage, and models.
 */

const { execFile } = require("child_process");
const { promisify } = require("util");
const fs = require("fs");
const path = require("path");

const execFileAsync = promisify(execFile);

async function checkCommand(cmd, args = ["-version"]) {
  try {
    const { stdout } = await execFileAsync(cmd, args, { timeout: 5000 });
    return { ok: true, version: stdout.split("\n")[0].trim() };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function main() {
  console.log("\n=== ClipForge AI — System Readiness Check ===\n");

  // OS
  console.log(`OS: ${process.platform} ${process.arch}`);
  console.log(`Node: ${process.version}`);

  // FFmpeg
  const ffmpeg = await checkCommand("ffmpeg");
  const ffprobe = await checkCommand("ffprobe");
  console.log(`\nFFmpeg:  ${ffmpeg.ok ? "✓ " + ffmpeg.version : "✗ NOT FOUND"}`);
  console.log(`FFprobe: ${ffprobe.ok ? "✓ " + ffprobe.version : "✗ NOT FOUND"}`);

  if (!ffmpeg.ok || !ffprobe.ok) {
    console.log("\n  Install FFmpeg:");
    if (process.platform === "darwin") console.log("    brew install ffmpeg");
    else if (process.platform === "win32")
      console.log("    winget install ffmpeg  or  choco install ffmpeg");
    else console.log("    sudo apt install ffmpeg   # or equivalent");
  }

  // Python
  const py = await checkCommand("python3", ["--version"]);
  console.log(`\nPython3: ${py.ok ? "✓ " + py.version : "✗ NOT FOUND"}`);

  // Storage
  const storageRoot = path.join(process.cwd(), "storage");
  const dirs = ["uploads", "exports", "temp", "models"];
  let storageOk = true;
  for (const d of dirs) {
    const p = path.join(storageRoot, d);
    try {
      fs.mkdirSync(p, { recursive: true });
      fs.accessSync(p, fs.constants.W_OK);
      console.log(`Storage ${d}/: ✓ writable`);
    } catch {
      console.log(`Storage ${d}/: ✗ not writable`);
      storageOk = false;
    }
  }

  // Models (placeholder)
  const modelsDir = path.join(storageRoot, "models");
  const whisperPath = path.join(modelsDir, "whisper");
  const hasWhisper = fs.existsSync(whisperPath);
  console.log(`\nWhisper model: ${hasWhisper ? "✓ present" : "○ not installed (optional)"}`);

  console.log("\n--- Summary ---");
  const ready = ffmpeg.ok && ffprobe.ok && storageOk;
  if (ready) {
    console.log("Core media pipeline: READY (Browser Lite + FFmpeg)");
    console.log("Full Local AI (transcription / scoring): requires worker + models");
  } else {
    console.log("NOT READY — fix items marked ✗ above");
  }
  console.log("");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
