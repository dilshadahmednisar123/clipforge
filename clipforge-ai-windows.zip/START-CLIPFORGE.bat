@echo off
REM Double-click this file to install dependencies and launch ClipForge
call "%~dp0scripts\windows\INSTALL-AND-RUN.bat"
